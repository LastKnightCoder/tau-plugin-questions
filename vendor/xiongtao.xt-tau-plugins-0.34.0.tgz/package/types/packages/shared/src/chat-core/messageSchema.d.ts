export declare const createChatMessageClientId: () => string;
