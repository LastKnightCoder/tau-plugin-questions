/**
 * 主题「海盐」—— 取自移动端海盐 Ocean（浅色·沉静）：盐雾蓝灰纸底 + 石板墨 + 海盐蓝 accent。
 *
 * 浅色（晴）：底色 / 墨色 / 品牌蓝沿用移动端取值；桌面对比度门禁更严（02 规范 §2.5），
 * ink-2 与 accent 按 AA 压深，并补齐移动端没有的 sunken / track 档。
 *
 * 深色（夜）：移动端无深色版，按同色相推演为「夜海」——深海军蓝底 + 盐白墨 + 海盐蓝提亮。
 * 层级与浅色对称翻转（同暖纸 · 夜的口径）：surface 最亮、sunken 最暗；交互态改盐白墨低透明
 * 叠层；阴影加深至黑系。
 */
declare const _default: import("../defineTheme").ThemeDefinition;
export default _default;
