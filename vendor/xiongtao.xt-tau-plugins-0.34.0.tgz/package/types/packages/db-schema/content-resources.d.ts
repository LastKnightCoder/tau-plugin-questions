export type ContentResourceKind = "image" | "video" | "audio" | "file";
export declare const CONTENT_RESOURCE_KINDS: readonly ContentResourceKind[];
export interface ContentResourceSpec {
    /** 字段路径：`url`、`images[].url`；`[]` 表示数组的每一项 */
    path: string;
    kind: ContentResourceKind;
    /** 同一资源的显示版本（如裁剪结果），与 path 末段同层的字段名，同样参与上传与改写 */
    preview?: string;
    /** 替代文字字段，与 path 末段同层 */
    alt?: string;
    /** 说明文字字段，与 path 末段同层 */
    caption?: string;
}
/** 节点类型 → 资源字段 */
export type ContentResourceDeclarations = Readonly<Record<string, readonly ContentResourceSpec[]>>;
/** 宿主内置节点的资源字段 */
export declare const BUILTIN_CONTENT_RESOURCES: {
    readonly image: readonly [{
        readonly path: "url";
        readonly kind: "image";
        readonly preview: "previewUrl";
        readonly alt: "alt";
        readonly caption: "description";
    }];
    readonly "inline-image": readonly [{
        readonly path: "url";
        readonly kind: "image";
        readonly alt: "alt";
    }];
    readonly audio: readonly [{
        readonly path: "src";
        readonly kind: "audio";
    }];
    readonly video: readonly [{
        readonly path: "src";
        readonly kind: "video";
    }];
    readonly "file-attachment": readonly [{
        readonly path: "filePath";
        readonly kind: "file";
    }, {
        readonly path: "localFilePath";
        readonly kind: "file";
    }];
};
export declare function isContentResourceSpec(value: unknown): value is ContentResourceSpec;
/** 校验来自插件或其他设备的声明；形状不对时抛错 */
export declare function assertContentResourceSpecs(value: unknown): asserts value is readonly ContentResourceSpec[];
/** 合并多份声明，后者覆盖同类型的前者 */
export declare function mergeContentResources(...sources: readonly ContentResourceDeclarations[]): ContentResourceDeclarations;
/** 资源所在的对象（字段的父对象）及字段名 */
export interface ContentResourceSlot {
    spec: ContentResourceSpec;
    owner: Record<string, unknown>;
    field: string;
}
/** 按声明列出一个节点里的资源位置（不深入子节点） */
export declare function contentResourceSlots(node: unknown, specs: readonly ContentResourceSpec[] | undefined): ContentResourceSlot[];
/** 资源位置上实际的地址：主地址与显示版本，空串跳过 */
export declare function contentResourceValues(slot: ContentResourceSlot): string[];
export interface ContentResourceEntry {
    node: Record<string, unknown>;
    slot: ContentResourceSlot;
}
/** 按文档顺序遍历节点树里所有声明了资源的位置 */
export declare function forEachContentResource(nodes: readonly unknown[], declarations: ContentResourceDeclarations, visit: (entry: ContentResourceEntry) => void): void;
/** 收集节点树里的资源地址（去重，保持首次出现的顺序） */
export declare function collectContentResources(nodes: readonly unknown[], declarations: ContentResourceDeclarations): {
    url: string;
    kind: ContentResourceKind;
}[];
export type ContentResourceMapper = (url: string, kind: ContentResourceKind) => string | undefined;
/** 不可变地改写一个节点里声明的资源（不深入子节点）；返回 undefined 表示保留原值 */
export declare function mapNodeResources<T>(node: T, specs: readonly ContentResourceSpec[] | undefined, mapper: ContentResourceMapper): T;
/** 不可变地改写整棵节点树里声明的资源 */
export declare function mapContentResources<T>(nodes: readonly T[], declarations: ContentResourceDeclarations, mapper: ContentResourceMapper): T[];
