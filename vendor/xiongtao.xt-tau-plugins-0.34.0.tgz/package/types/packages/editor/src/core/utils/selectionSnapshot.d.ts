import type { Editor } from "slate";
export declare const getSelectionSnapshot: (selection: Editor["selection"]) => string | null;
export declare const isSelectionSnapshotUnchanged: (editor: Editor, expectedSnapshot: string | null) => boolean;
