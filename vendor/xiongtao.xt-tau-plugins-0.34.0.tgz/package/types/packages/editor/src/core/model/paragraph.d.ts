import { type Node } from "slate";
import type { ParagraphElement } from "../types/element/paragraph";
export type { ParagraphElement } from "../types/element/paragraph";
export declare const createParagraph: () => ParagraphElement;
export declare const isParagraphElement: (node: Node) => node is ParagraphElement;
