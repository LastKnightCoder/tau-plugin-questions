export type FloatingPlacement = "top" | "bottom";
export type FloatingAnchorRect = {
    top: number;
    bottom: number;
    left: number;
    width: number;
};
export type CalculateFloatingPositionInput = {
    anchorRect: FloatingAnchorRect;
    viewportWidth: number;
    viewportHeight: number;
    floatingWidth: number;
    floatingHeight: number;
    gap?: number;
    preferredPlacement?: FloatingPlacement;
};
export type FloatingPosition = {
    top: number;
    left: number;
    placement: FloatingPlacement;
};
export declare function calculateFloatingPosition(input: CalculateFloatingPositionInput): FloatingPosition;
