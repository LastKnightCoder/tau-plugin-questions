import { type ReactNode } from "react";
import { type RenderElementProps } from "slate-react";
import type { ElementFrame as ElementFrameOptions } from "../../api/extension";
/** 选中描边：外扩 3px，随内容圆角 */
export declare const ELEMENT_SELECTED_OUTLINE_CLASS = "outline-solid outline-2 outline-offset-[3px] outline-[var(--ed-accent)]";
export interface ElementFrameState {
    selected: boolean;
    select(): void;
    deselect(): void;
    /** 在指定位置打开块菜单（与右键、块手柄同一份条目） */
    openMenu(position: {
        x: number;
        y: number;
    }): void;
}
/** 外框里的块读取选中与菜单状态；不在外框里时为 null */
export declare const useElementFrame: () => ElementFrameState | null;
/**
 * void 块的公共外框：点选与选中描边、右键菜单、选中时的删除与声明的按键、末尾「添加段落」。
 * 块的 render 只渲染内容，attributes 与 children 由外框处理。
 */
export declare function ElementFrame({ attributes, element, children, options, content, }: RenderElementProps & {
    options: ElementFrameOptions;
    content: ReactNode;
}): import("react/jsx-runtime").JSX.Element;
