import { Editor, type Path } from "slate";
import type { EditorCommandContext } from "../api/command";
/** 写入命令必须命中仍在当前文档中的原元素，菜单保存的旧路径不能指向替代节点。 */
export declare function getCommandElementPath(editor: Editor, context: EditorCommandContext): Path | null;
