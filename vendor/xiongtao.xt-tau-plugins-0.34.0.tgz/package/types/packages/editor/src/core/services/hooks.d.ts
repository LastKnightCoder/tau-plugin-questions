import type { ServiceIdentifier } from "./tokens";
import type { ServiceRegistry } from "./registry";
import type { EditorNotifier } from "./notifier";
/** 获取注册表本身，用于派生子注册表或非 React 场景转发 */
export declare function useServiceRegistry(): ServiceRegistry;
/** 获取必选服务，未注册时抛错 */
export declare function useService<T>(id: ServiceIdentifier<T>): T;
/** 获取可选服务，未注册时返回 undefined，由消费侧显式降级 */
export declare function useOptionalService<T>(id: ServiceIdentifier<T>): T | undefined;
/** 轻提示与确认：宿主没注册时用默认实现，编辑器组件不需要判空 */
export declare function useNotifier(): EditorNotifier;
