import type { SVGProps } from "react";
/** 实心右三角（折叠箭头）；随字号缩放，展开时由调用方旋转 90° */
export declare function CaretRight({ className, ...props }: SVGProps<SVGSVGElement>): import("react/jsx-runtime").JSX.Element;
