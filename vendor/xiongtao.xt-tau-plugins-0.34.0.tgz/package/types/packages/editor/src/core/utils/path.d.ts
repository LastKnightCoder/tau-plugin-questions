import { Editor, Node, Path } from "slate";
export declare const getPrevPath: (path: Path) => Path | undefined;
export declare const getNextPath: (path: Path) => Path;
export declare const getParentPath: (path: Path) => number[];
export declare const findPathSafely: (editor: Editor, node: Node) => Path | undefined;
export declare const getNodeAtPathSafely: (editor: Editor, path: Path) => Node | undefined;
