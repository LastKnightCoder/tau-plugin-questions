import type { ComponentType, MouseEvent, ReactNode, Ref } from "react";
/**
 * 块的拖拽手柄与放置指示，所有块共用。
 *
 * 显示逻辑按块隔离：块的外层容器加 `BLOCK_DRAG_GROUP`，带 `data-block-reveal` 的元素（手柄、标题折叠箭头）
 * 只在**最内层**被悬停的块里出现，规则见 `theme/editor.css`。
 * 不用 Tailwind 命名 group：`group-hover/x` 匹配的是「任意同名祖先被悬停」，嵌套块会一起亮。
 */
export declare const BLOCK_DRAG_GROUP = "ed-block";
export interface DragHandleProps {
    /** useDragAndDrop 返回的 drag 连接器 */
    dragRef: Ref<HTMLDivElement> | ((node: HTMLDivElement | null) => void);
    canDrag: boolean;
    onClick?: (event: MouseEvent) => void;
    /** 位置微调（经 cn 合并，可覆盖 top / left / height） */
    className?: string;
    /** 手柄图标；传 null 渲染无图标的热区 */
    icon?: ComponentType<{
        className?: string;
    }> | null;
    iconClassName?: string;
}
export declare function DragHandle({ dragRef, canDrag, onClick, className, icon: Icon, iconClassName, }: DragHandleProps): import("react/jsx-runtime").JSX.Element;
export interface DropIndicatorProps {
    /** 当前是否有可放置的拖拽经过本块 */
    active: boolean;
    /** 插入到本块之前（上方）还是之后（下方） */
    before: boolean;
    /** 位置微调（经 cn 合并，可覆盖 top / bottom） */
    className?: string;
}
/** 拖拽经过时的 accent 插入线；父元素需 position: relative */
export declare function DropIndicator({ active, before, className }: DropIndicatorProps): ReactNode;
/** 拖拽源 / 放置目标的半透明（原 .dragging / .drop 的 opacity: 0.5） */
export declare const dimWhileDragging: (dragging: boolean) => "opacity-50" | undefined;
