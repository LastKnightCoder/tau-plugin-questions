import { type OverlayBackDismissProps } from "../../services/overlayBackDismiss";
import React from "react";
/** 仅在 open 期间挂载宿主登记器；未提供服务时由浮层的按钮及焦点链关闭。 */
export default function OverlayBackDismiss(props: OverlayBackDismissProps): React.ReactElement<OverlayBackDismissProps, string | React.JSXElementConstructor<any>> | null;
