import type { ThemeService } from "../theme/ThemeService";
import type { ExtensionErrorReporter } from "./errorReporter";
import type { EditorNotifier } from "./notifier";
export { createServiceId, type ServiceIdentifier } from "../../../../shared/service-contract";
/** 主题服务：未注册时编辑器用 DOM 默认实现（读 <html> 的 data-mode / data-theme） */
export declare const IThemeService: import("../../../../shared/service-contract").ServiceIdentifier<ThemeService>;
/** 轻提示与确认：未注册时用 @tau/ui 的 toast（宿主需挂 ToastHost）与原生 confirm */
export declare const IEditorNotifier: import("../../../../shared/service-contract").ServiceIdentifier<EditorNotifier>;
/** 扩展运行期错误上报：未注册时写控制台 */
export declare const IExtensionErrorReporter: import("../../../../shared/service-contract").ServiceIdentifier<ExtensionErrorReporter>;
