import { Editor, Node, Path } from "slate";
import type { EditorFeedback } from "../services/notifier";
/**
 * 复制节点到剪贴板
 * 支持两种格式：JSON 和纯文本
 */
export declare function copyNodeToClipboard(_editor: Editor, element: Node, message?: EditorFeedback, options?: {
    allowPlainTextFallback?: boolean;
    signal?: AbortSignal;
}): Promise<boolean>;
/**
 * 删除节点
 * 如果是最后一个节点，则清空内容而不删除节点本身
 */
export declare function deleteNode(editor: Editor, path: Path): void;
/**
 * 删除 void 块并补一个空段落承接焦点（图片 / 音视频 / 代码块等不可聚焦块的统一删除语义）
 */
export declare function deleteVoidBlock(editor: Editor, path: Path): void;
