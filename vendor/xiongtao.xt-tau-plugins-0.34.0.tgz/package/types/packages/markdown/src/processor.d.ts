import type { Descendant } from "slate";
import type { MarkdownCodec } from "./codec";
import { type ImportFromMarkdownOptions, type SlateWithPositions } from "./markdown";
import { type MarkdownWithPositions } from "./markdown-helper";
import type { CustomElement } from "./types";
import type { FormattedText } from "./model";
import { type MarkdownTextCodec, type LeafSerializationResult } from "./textCodec";
export interface MarkdownProcessor {
    importFromMarkdown(markdown: string, ignoreTypes?: string[], options?: ImportFromMarkdownOptions): Descendant[];
    importFromMarkdownWithPositions(markdown: string, ignoreTypes?: string[], options?: ImportFromMarkdownOptions): SlateWithPositions;
    getMarkdown(value: Descendant[]): string;
    getMarkdownWithPositions(value: Descendant[]): MarkdownWithPositions;
    elementToMarkdown(element: CustomElement, parentElement: CustomElement | null): string;
    leafToMarkdown(leaf: FormattedText): string;
    leafToMarkdownStructured(leaf: FormattedText): LeafSerializationResult;
}
export interface MarkdownProcessorOptions {
    /** 元素类型的编解码（各扩展的 markdown.ts 提供）；处理器只认这里的类型，其余走 ER-006 兜底 */
    codecs?: MarkdownCodec[];
    textCodecs?: readonly MarkdownTextCodec[];
}
/**
 * 创建 Markdown 处理器（01 §8.2）：框架不带任何元素类型，全部经 codecs 注入，
 * 宿主把扩展包的 codec 列表（如 @tau/editor/markdown）与自己的业务 codec 合成一次，
 * 渲染进程和 Electron 主进程共用，避免两边漂移。
 */
export declare function createMarkdownProcessor(options?: MarkdownProcessorOptions): MarkdownProcessor;
