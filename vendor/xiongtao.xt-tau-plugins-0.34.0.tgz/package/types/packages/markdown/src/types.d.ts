import type { FormattedText } from "./model";
export type { FormattedText } from "./model";
/** 框架只看树结构；具体元素的字段和类型由 codec 解释。 */
export interface CustomElement {
    type: string;
    children: Array<CustomElement | FormattedText>;
}
export declare const isFormattedText: (node: CustomElement | FormattedText) => node is FormattedText;
