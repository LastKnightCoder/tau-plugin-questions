import type { MarkdownImportNode } from "./codec";
import type { FormattedText } from "./model";
export interface MarkdownTextRule {
    nodeType: string;
    directive?: string;
    content: "children" | "value";
    /** children 模式的源码包裹范围；指令沿用外层以保持既有位置口径。 */
    position?: "self" | "inherit";
    readMarks(node: MarkdownImportNode): Readonly<Record<string, unknown>> | null;
}
export interface MarkdownTextCodec {
    id: string;
    keys: readonly string[];
    importRules: readonly MarkdownTextRule[];
    exportWrap(leaf: Readonly<FormattedText>): {
        prefix: string;
        suffix: string;
    } | null;
}
export interface LeafSerializationResult {
    output: string;
    prefixLength: number;
    suffixLength: number;
    /** 转义载体中每个原文本边界相对 output 的偏移。 */
    sourceOffsets?: readonly number[];
}
/** 处理器实例私有的纯标记注册表，不加载 UI 或默认格式。 */
export declare class MarkdownTextRegistry {
    private readonly rules;
    private readonly keys;
    private readonly codecs;
    constructor(codecs: readonly MarkdownTextCodec[]);
    claim(node: MarkdownImportNode): {
        rule: MarkdownTextRule;
        marks: Readonly<Record<string, unknown>>;
    } | null;
    serialize(leaf: Readonly<FormattedText>): LeafSerializationResult;
    private serializeKnown;
}
