/**
 * 设置行 —— 设置分组面板内的标准行式（左侧标题+说明，右侧控件槽）。
 * 行高 ≥56px；同一面板内相邻行以 line-2 弱分隔（02 §2.3「列表行间」token，内收不贴面板边），
 * 分组之间靠 SettingsGroup 面板与留白区分。
 */
import type { ReactNode } from "react";
/** 面板内相邻行的 line-2 弱分隔（内收 12px）：自定义行（模型 / 文件行）也挂它，与 SettingRow 互相衔接 */
export declare const ROW_DIVIDER = "relative [&+&]:before:border-line-2 [&+&]:before:absolute [&+&]:before:inset-x-3 [&+&]:before:top-0 [&+&]:before:border-t";
export declare function SettingRow({ title, description, children, className, }: {
    title: ReactNode;
    description?: ReactNode;
    children?: ReactNode;
    className?: string;
}): import("react/jsx-runtime").JSX.Element;
