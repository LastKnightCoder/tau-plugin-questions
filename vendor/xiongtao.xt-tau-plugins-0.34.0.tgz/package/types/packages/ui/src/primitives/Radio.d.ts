/**
 * Radio —— 单选基础件（Input 方案 A「经典描边」语言，mockups/radio/，2026-09-19 定稿）。
 *
 * 原生 input[type=radio] 承载语义（appearance-none 自绘皮）：组内互斥、
 * 方向键移动即选择、读屏语义白送。形制是 Checkbox 的圆形同构：16×16 视觉圆
 * surface + line-1，选中 = 描边转 accent + 中心 accent 实点（110ms 缩放进场）。
 *
 * 结构铁律（同 Checkbox）：input / 圆环 / 中心点在同一层互为兄弟——peer-*
 * 变体只匹配 peer 的后续兄弟，深层后代会静默失效。状态语义（与 Input 裁决
 * 同源）：
 *  - 命中 24×24；focus-visible 才显 ring；hover 描边加深半档，聚焦时让位
 *  - 错误态正源 aria-invalid（未选中 danger），选中压过错误（选中优先）
 *  - 禁用：label 整项降透明 55%（fieldSet 组禁用时经 :disabled 传播同样生效）
 *
 * 单项不单独成组：须包在 RadioGroup 内（经 context 取 name/受控值），脱离组
 * 使用时自传 name，checked/defaultChecked/onChange 走原生透传。
 */
import { type ComponentProps, type ReactNode } from "react";
export interface RadioProps extends Omit<ComponentProps<"input">, "type"> {
    /** 选项值（组内唯一；选中态 = RadioGroup.value 等于此值） */
    value: string;
    /** 主标签（点文字同选；组内忽略 checked 类受控 prop，值归组） */
    label?: ReactNode;
    /** 描述行（label 下方两行排布，顶对齐；说明性文案走 tau-meta 下限） */
    description?: ReactNode;
}
export declare function Radio({ value, label, description, className, disabled, ...props }: RadioProps): import("react/jsx-runtime").JSX.Element;
