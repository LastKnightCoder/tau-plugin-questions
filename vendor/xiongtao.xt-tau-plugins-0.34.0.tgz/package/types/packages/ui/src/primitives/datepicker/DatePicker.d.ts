/**
 * DatePicker 基础件 —— 经典月历单日期（A+ 形态，mockups/datepicker/）。
 *
 * 值形状拆分的单日期侧：value: string | null（"YYYY-MM-DD"，precision="minute"
 * 时 "YYYY-MM-DD HH:mm"）；范围归 DateRangePicker（同一引擎，别在此加 range）。
 *
 * 分层（同 Popover/AnchoredPanel）：DatePickerPanel 是可独立使用的内嵌面板
 * （受控显示 + onCommit 确定，块级渲染，无开合无定位——宿主托管场景直接用它，
 * 如行内编辑器浮层）；DatePicker = 触发器 + 开合 + 定位 + 外点仲裁 + Panel。
 *
 * 行为内建（不做成 props）：
 *  - 提交模型跟着 precision 走：day 点日期即提交；minute 点日期只挂起，
 *    底栏时刻区（TimeField：自由键入 + 步长网格）+「确定」显式提交——带时间的
 *    值改起来贵，不做即点即定；预设（presets）取值即完整，一律即点即定
 *  - 钻取导航：点标题 days → months → 年代（12 格），‹ › 步长随视图换
 *  - 键盘全表：触发器 ↑↓·Enter 开面板；面板内方向键 / PgUp·PgDn 翻月 / T 今天 /
 *    Enter 提交；Esc 逐层退场（时刻网格先收，再关面板），焦点归还触发器
 *  - 定位复用 D-004 引擎（bottom + gap 4，flip 跟随）；外点关闭（useLayerDismiss）；
 *    层级 z-[250] 与 Select/Menu 同层
 *  - 预设行显示在日历下方：presets 数据驱动（label + 取值函数），内容与措辞
 *    归使用方，组件不内置业务词表；当前值命中时该 chip 高亮回显
 */
import { type ReactNode, type Ref } from "react";
import { type DatePrecision } from "./calendarEngine";
export type { DatePrecision } from "./calendarEngine";
export interface DatePickerPreset {
    label: ReactNode;
    /** 调用时求值（"今天"这类动态日期每次打开都新鲜）；返回 null 表示清空 */
    value: () => string | null;
}
export interface DatePickerPanelProps {
    /** 受控显示值（"YYYY-MM-DD" / "YYYY-MM-DD HH:mm"） */
    value: string | null;
    /** 确定提交：day 点日期 / minute 确定 / 预设 / 今天 / 清空 */
    onCommit: (value: string | null) => void;
    precision?: DatePrecision;
    presets?: readonly DatePickerPreset[];
    timeStep?: number;
    disabled?: boolean;
    /** 禁用日期谓词（入参 "YYYY-MM-DD"，业务侧零 Date 依赖） */
    isDateDisabled?: (day: string) => boolean;
    className?: string;
    ref?: Ref<HTMLDivElement>;
}
export declare function DatePickerPanel({ value, onCommit, precision, presets, timeStep, disabled, isDateDisabled, className, ref, }: DatePickerPanelProps): import("react/jsx-runtime").JSX.Element;
export interface DatePickerProps {
    value?: string | null;
    defaultValue?: string | null;
    onValueChange?: (value: string | null) => void;
    /** 值粒度：day（默认，"YYYY-MM-DD"）| minute（"YYYY-MM-DD HH:mm"，底栏时刻区 + 确定提交） */
    precision?: DatePrecision;
    /** 预设行（日历下方）：数据驱动，即点即定 */
    presets?: readonly DatePickerPreset[];
    placeholder?: string;
    size?: "sm" | "md";
    /** 触发器 hover 浮出清除（值回 null） */
    clearable?: boolean;
    /** 禁用日期谓词（入参 "YYYY-MM-DD"，业务侧零 Date 依赖） */
    isDateDisabled?: (day: string) => boolean;
    /** 时刻网格步长（分钟），默认 15 */
    timeStep?: number;
    disabled?: boolean;
    /** Field 体系错误态（danger 描边） */
    status?: "error";
    /** 浮层受控（§5.3 契约；样板间常显标本用它） */
    open?: boolean;
    onOpenChange?: (open: boolean) => void;
    className?: string;
    ref?: Ref<HTMLButtonElement>;
}
export declare function DatePicker({ value: valueProp, defaultValue, onValueChange, precision, presets, placeholder, size, clearable, isDateDisabled, timeStep, disabled, status, open: openProp, onOpenChange, className, ref, }: DatePickerProps): import("react/jsx-runtime").JSX.Element;
