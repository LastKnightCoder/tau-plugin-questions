/**
 * DateRangePicker 基础件 —— 范围形态（B 形态并入，mockups/datepicker/ 方案 B）。
 *
 * 值形状拆分的范围侧：value: readonly [string, string] | null（两端均
 * "YYYY-MM-DD"，precision="minute" 时为 "YYYY-MM-DD HH:mm"；升序，逆序输入按升序读取）。与 DatePicker 同一引擎（CalendarPanel/弹层契约/触发器皮），
 * 收起预设列与底栏、去掉 range 即回到单日期形态——不是第二个日历，是同一结构的
 * 范围扩展态。
 *
 * 分层（同 DatePicker/DatePickerPanel）：DateRangePickerPanel 是可独立使用的
 * 内嵌面板（受控显示 + onCommit 确定，块级渲染，无开合无定位——宿主托管场景
 * 直接用它）；DateRangePicker = 触发器 + 开合 + 定位 + 外点仲裁 + Panel。
 *
 * 行为内建（不做成 props）：
 *  - 提交模型：手选范围走「点起点 → 悬停预览 → 点终点（自动交换）→ 确定」三道闸
 *    （范围错一格就触发下游重查询，不做即点即定）；预设即选即定
 *  - 双月并排（跨月范围不翻页）：左 ‹ 右 › 承载翻月，中间 line-2 弱分隔；
 *    界外日隐藏，同一天不会在两个面板重复出现
 *  - minute 精度：两月下方各一个时刻区（左开始 / 右结束），同日结束早于开始时禁止确定
 *  - 用色纪律：端点 accent 实底、中段 accent-soft，色彩表意不装饰
 *  - 底栏摘要（"9月12日 – 9月19日 · 共 8 天"）是提交前最后一眼确认
 *  - 键盘：Enter 确定 / Esc 放弃预览并关闭（焦点归还触发器）
 */
import { type Ref } from "react";
import { type DatePrecision } from "./calendarEngine";
export interface DateRangePreset {
    label: string;
    /** 调用时求值（"本周"这类动态范围每次打开都新鲜）；返回 null 表示清空 */
    range: () => readonly [string, string] | null;
}
export interface DateRangePickerPanelProps {
    /** 受控显示值（两端按 precision 的值串，升序） */
    value: readonly [string, string] | null;
    /** day 只选日期；minute 追加开始/结束时刻区。默认 day */
    precision?: DatePrecision;
    /** 时刻网格步长（分钟），默认 15 */
    timeStep?: number;
    /** 确定提交：手选「确定」/ 预设即点即定 / 清空 */
    onCommit: (value: [string, string] | null) => void;
    /** 面板当前展示的区间（含未确定的草稿）变化时回调；只选了起点时终点为 "" */
    onPreviewChange?: (value: readonly [string, string] | null) => void;
    presets?: readonly DateRangePreset[];
    disabled?: boolean;
    /** 禁用日期谓词（入参 "YYYY-MM-DD"，业务侧零 Date 依赖） */
    isDateDisabled?: (day: string) => boolean;
    className?: string;
    ref?: Ref<HTMLDivElement>;
}
export declare function DateRangePickerPanel({ value: valueProp, onCommit, onPreviewChange, precision, timeStep, presets, disabled, isDateDisabled, className, ref, }: DateRangePickerPanelProps): import("react/jsx-runtime").JSX.Element;
export interface DateRangePickerProps {
    value?: readonly [string, string] | null;
    defaultValue?: readonly [string, string] | null;
    onValueChange?: (value: [string, string] | null) => void;
    /** day 只选日期；minute 追加开始/结束时刻区。默认 day */
    precision?: DatePrecision;
    /** 时刻网格步长（分钟），默认 15 */
    timeStep?: number;
    /** 预设列（面板左列）：数据驱动，即选即定 */
    presets?: readonly DateRangePreset[];
    placeholder?: string;
    size?: "sm" | "md";
    clearable?: boolean;
    isDateDisabled?: (day: string) => boolean;
    disabled?: boolean;
    status?: "error";
    open?: boolean;
    onOpenChange?: (open: boolean) => void;
    className?: string;
    ref?: Ref<HTMLButtonElement>;
}
export declare function DateRangePicker({ value: valueProp, defaultValue, onValueChange, precision, timeStep, presets, placeholder, size, clearable, isDateDisabled, disabled, status, open: openProp, onOpenChange, className, ref, }: DateRangePickerProps): import("react/jsx-runtime").JSX.Element;
