/**
 * Popover 基础件 —— 锚定式可交互内容浮层（D-014）。
 *
 * 家族分工：Tooltip 瞬态说明（hover/focus、不可交互）、Menu 命令面板、Select 表单值
 * 选择、Dialog 模态决策、Toast 回执；Popover 收「点击触发、内容可继续操作」的
 * 非模态浮层——说明卡 / 过滤器组 / 色板 / 成员卡 / 卡片预览。antd 存量 Popover 的
 * trigger="hover" 用法迁 Tooltip、placement 12 向同名直映（D-014 迁移口径）。
 *
 * 定位与卡片视觉组合自 AnchoredPanel（基座只有一份）；本件叠加交互层：
 *  - click toggle（hover 说明归 Tooltip，不设 trigger props；右键归 ContextMenu）
 *  - 外点关闭 + 嵌套链共存 + 顶层互斥（useLayerDismiss：浮层内开的 Menu/Select/
 *    二级 Popover 不算外点）
 *  - Esc 仅 open 态消费（焦点链 LIFO，同 Select/Menu/Dialog 口径，不进 D-003
 *    注册表——ui 不反向依赖 page/）；Esc/Tab 关闭还焦触发器
 *  - 打开落初始焦点：卡片内 [data-autofocus] 优先（表单放首输入框），否则卡片自身
 *  - Tab 移出即关（非模态不圈闭）
 *  - aria：卡片 role=dialog（非模态，无 aria-modal）+ aria-labelledby 头行；
 *    触发器 aria-haspopup=dialog + aria-expanded
 *  - 受控 open / onOpenChange（§5.3 浮层 open 契约；样板间常显标本用它）
 */
import { type ReactElement, type ReactNode } from "react";
import type { AnchoredPlacement } from "./anchoredPosition";
export interface PopoverProps {
    /**
     * 触发器（单一元素，克隆注入开合事件 / aria / ref）。协议同 Tooltip/Menu：元素
     * 必须透传 props 与 ref——原生元素或 {...rest} 透传的组件；不透传的包装组件会
     * 吞掉注入，点击无反应。
     */
    trigger?: ReactElement;
    /** 已存在的交互元素可直接作为锚点，适用于虚拟列表单元格。 */
    anchor?: HTMLElement | null;
    locked?: boolean;
    /** 内容：Popover.Header / Body / Footer 复合声明（裸内容无内边距，自查排版） */
    children: ReactNode;
    /** 12 向全表（引擎 flip/shift 兜底），默认 top */
    placement?: AnchoredPlacement;
    /** 浮层受控（§5.3 契约；样板间常显标本用它） */
    open?: boolean;
    onOpenChange?: (open: boolean) => void;
    /** 箭头（默认开；8px 菱形，随 flip 自动换边） */
    arrow?: boolean;
    /** 透传浮层卡片（宽度控制如 w-[360px]，覆盖 min/max 约束） */
    className?: string;
}
export declare function Popover({ trigger, anchor, locked, children, placement, open: openProp, onOpenChange, arrow, className, }: PopoverProps): import("react/jsx-runtime").JSX.Element;
export declare namespace Popover {
    var Header: typeof PopoverHeader;
    var Body: ({ children, className }: import("./AnchoredPanel").AnchoredPanelBodyProps) => import("react/jsx-runtime").JSX.Element;
    var Footer: ({ children, className }: import("./AnchoredPanel").AnchoredPanelFooterProps) => import("react/jsx-runtime").JSX.Element;
}
export interface PopoverHeaderProps {
    /** 16px lucide 图标（圆底 accent-soft） */
    icon?: ReactNode;
    children: ReactNode;
}
/** 头行：随需出现——说明卡/过滤器用它，色板/成员卡可省（零框架税） */
declare function PopoverHeader({ icon, children }: PopoverHeaderProps): import("react/jsx-runtime").JSX.Element;
export {};
