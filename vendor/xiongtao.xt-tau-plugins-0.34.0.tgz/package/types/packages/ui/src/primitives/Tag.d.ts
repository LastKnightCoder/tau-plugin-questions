/**
 * Tag —— 值展示标签（A+B 结合 II「点 + 软底」，mockups/tag/plan-ab-dot-soft.html，
 * 2026-09-19 定稿）。
 *
 * soft 底 + 同系 solid 文字（B 的色块扫读）+ 可选 solid 色点（A 的色相焦点）：
 * 三层同色阶，Notion select 选项标签语感。无色 = 无分类——默认 gray 走
 * group 底 + ink-2 文字且恒无点。纯展示 span：非交互、无命中要求；
 * onRemove 数据驱动显 ×（button + aria-label，伪元素把热区扩到 24、
 * focus-visible 才显 ring、点击不冒泡——表格行点击不受牵连）。
 *
 * 单尺寸（高 22、字 tau-sm）无档；长文本 truncate 由容器约束 max-width。
 */
import type { ComponentProps } from "react";
export declare const TAG_COLORS: readonly ["red", "orange", "yellow", "green", "gray", "blue", "purple"];
export type TagColor = (typeof TAG_COLORS)[number];
export interface TagProps extends Omit<ComponentProps<"span">, "color"> {
    /** 分类色（7 色板，与 ColorSwatch 同源）；语义状态复用色板，不另设 status */
    color?: TagColor;
    /** 色相焦点（默认开）；gray 恒无点——无色 = 无分类 */
    showDot?: boolean;
    /** 传了才渲染移除钮 ×（热区 24，点击不冒泡） */
    onRemove?: () => void;
}
export declare function Tag({ color, showDot, onRemove, className, children, ...props }: TagProps): import("react/jsx-runtime").JSX.Element;
