import React from "react";
interface IEditTextProps {
    id?: string;
    className?: string;
    style?: React.CSSProperties;
    defaultValue?: string;
    value?: string;
    placeholder?: string;
    placeholderClassName?: string;
    placeholderStyle?: React.CSSProperties;
    contentEditable?: boolean;
    onChange?: (value: string) => void;
    onPressEnter?: () => void;
    onDeleteEmpty?: () => void;
    defaultFocus?: boolean;
    onBlur?: () => void;
    onKeyDown?: (e: KeyboardEvent) => void;
    isSlateEditor?: boolean;
}
export type EditTextHandle = {
    clear: () => void;
    setValue: (value: string) => void;
    focus: () => void;
    isFocus: () => boolean;
    focusEnd: () => void;
    selectAll: () => void;
    blur: () => void;
    getValue: () => string;
    setContentEditable: (editable: boolean) => void;
};
export declare const EditText: React.NamedExoticComponent<IEditTextProps & React.RefAttributes<EditTextHandle>>;
export default EditText;
