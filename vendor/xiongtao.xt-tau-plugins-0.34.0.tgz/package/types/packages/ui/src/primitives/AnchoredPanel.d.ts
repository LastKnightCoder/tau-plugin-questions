/**
 * AnchoredPanel 基础件 —— 锚定面板：浮层家族的定位基座（Radix Popper 同构层）。
 *
 * 与 Popover 的分工：AnchoredPanel 只管锚定定位（D-004 引擎）、卡片视觉、portal
 * 与显隐过渡——无开合状态（默认锚点在即显示，open 可由宿主驱动）、不监听外点、
 * 不消费 Esc/Tab、不抢焦点，键盘与焦点事件原样冒泡给宿主仲裁。Popover 组合它并
 * 叠加交互层（trigger 注入、外点/Esc/Tab 仲裁、焦点契约、dialog 语义）；卡片与
 * Body/Footer 的视觉形制只有本文件一份。
 *
 * 直接使用的场景：浮层是某个交互会话的一部分、生命周期完全由宿主拥有——如行内
 * 编辑器的选项面板（编辑会话在，面板在；失焦/Esc 由编辑宿主统一判定）。需要独立
 * 开合的浮层用 Popover，勿直接用此件。
 */
import { type HTMLAttributes, type ReactNode, type Ref } from "react";
import { type AnchoredPlacement } from "./anchoredPosition";
/** Body 顶部间距按有无头行分流（头行自带 pb）；由带头行的容器（如 Popover）提供 */
export declare const PanelHasHeaderContext: import("react").Context<boolean | null>;
export interface AnchoredPanelProps extends Omit<HTMLAttributes<HTMLDivElement>, "children" | "className"> {
    /** 锚点元素；为空时不渲染（宿主常在 ref 就绪后再挂） */
    anchor: HTMLElement | null;
    /** 12 向全表（引擎 flip/shift 兜底），默认 bottom-start */
    placement?: AnchoredPlacement;
    /** 显隐由宿主驱动；缺省锚点存在即显示（宿主托管用法） */
    open?: boolean;
    /** 8px 菱形箭头（随 flip 换边），默认关 */
    arrow?: boolean;
    /** 透传浮层卡片（宽度控制如 w-[360px]，覆盖 min/max 约束） */
    className?: string;
    children: ReactNode;
    /** 卡片 DOM 引用（AnchoredPanel 内部已占用一位做定位，此处合并外部引用） */
    ref?: Ref<HTMLDivElement>;
}
export declare function AnchoredPanel({ anchor, placement, open, arrow, className, children, ref: externalRef, ...cardProps }: AnchoredPanelProps): import("react").ReactPortal | null;
export declare namespace AnchoredPanel {
    var Body: typeof AnchoredPanelBody;
    var Footer: typeof AnchoredPanelFooter;
}
export interface AnchoredPanelBodyProps {
    children: ReactNode;
    className?: string;
}
/** 正文：独立滚动（上限 min(60vh, 420px)）+ 边缘渐隐 + 透明右边框挤位（D-012 手法，
 *  浮层滚动区通用口径）；顶部间距按有无头行分流：无头行自足 14px，有头行收敛 10px。
 *  滚动轨道上下让位（track margin；track 透明边框不缩短 thumb 活动区）：贴浮层边缘的一端
 *  让出圆角半径，免得 thumb 画进 rounded-tau-lg 的圆角外；头行下方只留 4px */
declare function AnchoredPanelBody({ children, className }: AnchoredPanelBodyProps): import("react/jsx-runtime").JSX.Element;
export interface AnchoredPanelFooterProps {
    children: ReactNode;
    className?: string;
}
/** 应答区：随需——无操作即无 footer；按钮右对齐（主按钮恒在最右） */
declare function AnchoredPanelFooter({ children, className }: AnchoredPanelFooterProps): import("react/jsx-runtime").JSX.Element;
export {};
