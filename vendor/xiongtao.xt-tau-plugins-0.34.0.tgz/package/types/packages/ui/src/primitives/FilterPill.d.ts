/**
 * 筛选 pill：页面工具栏里的单选筛选项（分类 / 来源 / 状态 / 卡组），可带图标与计数。
 * 选中 = selected 底 + accent 字；未选有两种皮肤：outline = line-1 描边，raised = surface 底 + 卡片投影。
 * 选中与否由调用方受控，本组件只报点击；className 经 cn 合并，可覆盖未选中的文字色（如警示）。
 */
import type { ReactNode } from "react";
export interface FilterPillProps {
    active: boolean;
    onClick(): void;
    label: string;
    /** 不传即不渲染 */
    count?: number;
    /** 标签前的图标（调用方自定尺寸与间距） */
    icon?: ReactNode;
    /** 未选中的皮肤，默认 outline */
    variant?: "outline" | "raised";
    className?: string;
}
export declare function FilterPill({ active, onClick, label, count, icon, variant, className, }: FilterPillProps): import("react/jsx-runtime").JSX.Element;
