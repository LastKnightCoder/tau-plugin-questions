/**
 * Textarea —— 多行文本输入（与 Input 同形，mockups/input/ 方案 A）。
 *
 * 与 Input 共用形制语言（surface + line-1 + focus ring）；差异只有三点：
 * 多行布局、纵向起始对齐、maxLength 传值时右下角自动出计数器
 * （超限转 danger——超限即不可再输，计数是唯一提示，安静而确定）。
 * 错误态同样走原生 aria-invalid（视觉与读屏同源），文案归 Field 体系。
 */
import { type ComponentProps } from "react";
export interface TextareaProps extends ComponentProps<"textarea"> {
    /** 传值即在右下角渲染计数器（n / maxLength，超限转 danger） */
    maxLength?: number;
}
export declare function Textarea({ className, onChange, defaultValue, maxLength, rows, ...props }: TextareaProps): import("react/jsx-runtime").JSX.Element;
