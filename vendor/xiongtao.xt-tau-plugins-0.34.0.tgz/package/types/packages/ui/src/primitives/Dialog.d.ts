/**
 * Dialog 基础件 —— 模态决策容器 + ConfirmDialog 语义预设（形制与行为裁决见 D-011）。
 *
 * 形制：体内大标题 + 上下文徽标（context）+ hairline 应答区（主按钮最右，按钮序列
 * 由 footer 提供）+ blur 遮罩；长内容滚动区接 edge fade（对齐壳层 useEdgeFade
 * 协议）。阻断通知不带 icon，文字头部与其它对话同构（D-011）。
 *
 * 行为内建（不做成 props）：
 *  - 开合动效：遮罩淡入 + 卡片 scale(0.97)+translateY(8px)，退场等长后卸载；根上带
 *    data-morph（视图转场进行中）时一步到位到终态——转场更新期间 rAF 不触发，入场
 *    动效跑不起来，浏览器要截的是终态。卡片 data-state=open|closed 供形变定位就绪
 *  - Esc：仅 open 态在卡片 DOM 消费（stopPropagation）——焦点圈闭保证 Esc 必落
 *    卡片，焦点链即 LIFO，不进 D-003 注册表（同 D-007/D-010 口径，ui 不反向依赖
 *    page/）；critical 抖动拒绝
 *  - 关闭矩阵：dismissible = × + Esc + 遮罩点击；critical = 无 ×、遮罩点击抖动；
 *    locked（异步 loading）= 全失效
 *  - Tab 圈闭（首尾环绕）· 打开记录触发元素、关闭归还焦点
 *  - 初始焦点落卡片内 [data-autofocus] 元素（无则卡片自身）；表单场景把
 *    data-autofocus 放首输入框，danger 场景放取消按钮
 *  - 打开锁定底层滚动；卡片是限高（78vh）的 flex 列，头尾钉住
 *
 * 正文组合（同 MUI DialogContent / Chakra ModalBody）：卡片不替内容决定滚动，
 * children 原样排在标题与应答区之间。常规正文包 <DialogBody>——它是滚动区
 * （edge fade + 内缩滚动条 + 标准内边距）；放在 DialogBody 之外的内容自然钉住
 * 不随正文滚动（元信息行、标签栏等）；工作台型弹窗（双栏树 + 预览等）不用
 * DialogBody，配合 height 定高由内容自行分栏滚动。
 *
 * 自定义头部：`header` 整体替换内建标题行与 ×（工作台型弹窗自带导航头时用），
 * 关闭入口由 header 自行提供；`title` 仍是对话框的无障碍名称。
 *
 * 尺寸档是预设不是牢笼（D-011）：sm 380 / md 440（默认）/ lg 560，width 任意值覆盖；
 * 高度默认随内容（上限 78vh），height 定高（仍不超 82vh）。
 * 层级：遮罩容器 z-[340]（Select/Menu 250 < Tooltip 300 之上，Toast 360 之下——弹窗里的操作反馈须可见）。
 */
import { type KeyboardEvent as ReactKeyboardEvent, type ReactNode, type Ref } from "react";
export interface DialogProps {
    open: boolean;
    /** 提前挂载内容，待异步初始化完成后再显示并接管焦点。 */
    contentReady?: boolean;
    onOpenChange: (open: boolean) => void;
    /** 退场完成且内容卸载后调用，可在此清理业务草稿。 */
    onAfterClose?: () => void;
    title: string;
    /** 替换内建标题行与 ×；关闭入口由调用方在 header 内提供，title 转为 aria-label */
    header?: ReactNode;
    /** 标题左侧图标（16px、ink-2，随需出现；阻断通知等场景保持纯文字头部） */
    icon?: ReactNode;
    /** 标题下的次级说明行（meta 字号，随需出现） */
    subtitle?: string;
    /** 操作对象（上下文徽标，随需出现；标题保持动作语义） */
    context?: string;
    /** footer 影响行——后果量化贴决策点；impactDanger 走 danger 色 */
    impact?: string;
    impactDanger?: boolean;
    /** critical：无 ×，遮罩/Esc 抖动拒绝——「必须作答」档 */
    critical?: boolean;
    /** 关闭路径全封锁（异步进行中，半途关闭即坏文件） */
    locked?: boolean;
    size?: "sm" | "md" | "lg";
    /** 任意宽度（px）覆盖 size——业务特殊版式不必硬凑档位 */
    width?: number;
    /** 卡片定高（px，不超 82vh）——工作台型弹窗由内容自管滚动时用，避免高度随内容跳动 */
    height?: number;
    /** 应答区按钮序列（主按钮恒在最右；组件自身不渲染按钮） */
    footer?: ReactNode;
    children?: ReactNode;
    /** 卡片 onKeyDown 透传（ConfirmDialog 用它接管 Enter 默认应答） */
    onKeyDown?: (e: ReactKeyboardEvent<HTMLDivElement>) => void;
    className?: string;
    ref?: Ref<HTMLDivElement>;
}
export declare function Dialog({ open, contentReady, onOpenChange, onAfterClose, title, header, icon, subtitle, context, impact, impactDanger, critical, locked, size, width, height, footer, children, onKeyDown, className, ref, }: DialogProps): import("react").ReactPortal | null;
export interface DialogBodyProps {
    children?: ReactNode;
    className?: string;
}
/**
 * Dialog 正文滚动区：同 FadeScroll 的内缩滚动条（轨道上下各留 10px，不贴头尾），右侧 6px
 * 透明边、右内边距相应减 6px；只纵向滚动（内容借位负外边距超出时不冒横向滚动条）。
 * 底部留白按有无应答区取：有则贴 hairline 前留 22px，无则滚动区离卡片底 16px。
 */
export declare function DialogBody({ children, className }: DialogBodyProps): import("react/jsx-runtime").JSX.Element;
