/**
 * 面板（白卡）族 —— 壳层内容区的基础卡片容器（A2 视觉：surface 底 + shadow-card）。
 * pad 三档：base（宽松版式 18/20）、compact（今日页紧凑版式 12/16）、none（自管内距）。
 * variant：raised（默认，阴影白卡，直接落在 page 底上）/ outline（细描边，落在一整张纸上——纸上再叠阴影卡会糊成一片）。
 * PanelTitle 的下间距由调用方按域密度给（mb-1.5 / mb-2.5），避免同属性类层叠不可控。
 */
import type { ComponentProps } from "react";
declare const PANEL_VARIANTS: {
    readonly raised: "shadow-card";
    readonly outline: "border border-line-1";
};
declare const PANEL_PADS: {
    readonly base: "px-5 py-[18px]";
    readonly compact: "px-4 py-3";
    readonly none: "";
};
export declare function Panel({ className, pad, variant, ...props }: ComponentProps<"section"> & {
    pad?: keyof typeof PANEL_PADS;
    variant?: keyof typeof PANEL_VARIANTS;
}): import("react/jsx-runtime").JSX.Element;
export declare function PanelTitle({ className, ...props }: ComponentProps<"h2">): import("react/jsx-runtime").JSX.Element;
/** 标题行右侧的说明小字（flex 布局下与标题的间距由 gap 提供） */
export declare function PanelNote({ className, ...props }: ComponentProps<"small">): import("react/jsx-runtime").JSX.Element;
/** 板内空态注记（描边行，替代原 board-note 空态用法） */
export declare function EmptyNote({ className, ...props }: ComponentProps<"p">): import("react/jsx-runtime").JSX.Element;
/** 标题行右侧的“前往”链接（无背景，贴卡片右缘，与标题同行对齐）—— 今日页 / 发布页等共用 */
export declare function PanelAction({ className, ...props }: ComponentProps<"button">): import("react/jsx-runtime").JSX.Element;
export {};
