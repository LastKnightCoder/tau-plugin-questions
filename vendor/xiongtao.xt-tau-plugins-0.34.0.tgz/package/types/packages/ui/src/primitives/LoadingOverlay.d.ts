import type { ReactNode } from "react";
/** 进行中时在内容上盖一层半透明遮罩与转圈；内容保持渲染 */
export declare function LoadingOverlay({ loading, className, children, }: {
    loading: boolean;
    className?: string;
    children: ReactNode;
}): import("react/jsx-runtime").JSX.Element;
