/**
 * 日历引擎 —— DatePicker / DateRangePicker 共享的纯函数层。
 *
 * 值协议（string，不外泄 Date 对象）：
 *  - precision="day"     → "YYYY-MM-DD"
 *  - precision="minute"  → "YYYY-MM-DD HH:mm"
 * 解析一律本地时区并做回读校验（"2026-02-31" 这类越界串返回 null，不静默滚动）。
 * 六周固定 42 格：面板高度不随月跳变，界外日参与导航与点选（跨月自动接管视图）。
 */
export declare const WEEKDAY_LABELS: readonly ["一", "二", "三", "四", "五", "六", "日"];
export declare const WEEKDAY_NAMES: readonly ["日", "一", "二", "三", "四", "五", "六"];
export type DatePrecision = "day" | "minute";
export declare function toDateKey(date: Date): string;
/** "YYYY-MM-DD" → 本地 Date（当天 00:00）；格式不符或日历上不存在的日期返回 null */
export declare function parseDateKey(key: string): Date | null;
export declare function formatValue(date: Date, precision: DatePrecision): string;
/** 接受两种精度的值串；带无效时刻的 minute 串按 day 落（时刻归一化见 normalizeTimeInput） */
export declare function parseValue(value: string): Date | null;
export declare function sameDay(a: Date, b: Date): boolean;
export declare function addDays(date: Date, n: number): Date;
export declare function addMonths(date: Date, n: number): Date;
/** 周一起始的当周周一 */
export declare function startOfWeekMonday(date: Date): Date;
/** 某月的六周固定网格（周一起始；首尾补界外日，inMonth 标记界内） */
export declare function monthCells(year: number, monthIndex: number): {
    date: Date;
    key: string;
    inMonth: boolean;
}[];
/**
 * 时刻归一化："9" → "09:00"、"9:5" → "09:05"、"09:05" 直映（中文冒号兼容）；
 * 越界（时 >23 / 分 >59）或非数字返回 null。
 */
export declare function normalizeTimeInput(text: string): string | null;
/** 一天的时刻网格刻度（step 分钟，默认 15）："00:00"、"00:15" … "23:45" */
export declare function timeGridValues(step?: number): string[];
/** 时刻 → 网格最近刻度（"10:37" 步长 15 → "10:30"）；值不在步长上时网格无命中格 */
export declare function nearestStep(time: string, step?: number): string;
/** 触发器显示格式："2026年9月19日"（minute 追加 " 15:00"） */
export declare function formatDisplay(value: string): string;
/**
 * 范围显示格式：同年省年份（"9月12日 – 9月19日"），跨年两端补全；
 * minute 值追加时刻，同日只写一次日期（"9月12日 09:00 – 18:00"）
 */
export declare function formatRangeDisplay(start: string, end: string): string;
