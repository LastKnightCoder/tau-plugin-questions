import type { ComponentType } from "react";
export declare function ImagePreview({ images, index, onIndexChange, open, onOpenChange, ImageComponent, }: {
    images: readonly {
        src: string;
        alt?: string;
    }[];
    index: number;
    onIndexChange: (index: number) => void;
    open: boolean;
    onOpenChange: (open: boolean) => void;
    ImageComponent?: ComponentType<{
        src: string;
        alt: string;
        className?: string;
    }>;
}): import("react/jsx-runtime").JSX.Element;
