import { type ReactNode } from "react";
import { type ThemeMode } from "../../themes/src/index";
export declare function usePortalContainer(): HTMLElement;
/** 模态内的浮层留在同一层叠上下文，挂载点避开正文滚动区。 */
export declare function PortalScope({ children }: {
    children: ReactNode;
}): import("react/jsx-runtime").JSX.Element;
/**
 * 局部主题作用域：theme / mode 任一给定即建立作用域（数据块按 主题族 × 明暗 双属性匹配，
 * 缺省的一侧取默认主题族 / 浅色）；都不给则继承 <html> 上的全局主题。
 */
export declare function UiProvider({ children, theme, mode, className, }: {
    children: ReactNode;
    theme?: string;
    mode?: ThemeMode;
    className?: string;
}): import("react/jsx-runtime").JSX.Element;
