/**
 * 滚动条自动隐藏 —— 事件委托驱动，AppShell 初始化一次、全局滚动区生效。
 *
 * 为什么不用纯 CSS（.app *:hover::-webkit-scrollbar-thumb）：Chromium 的滚动条
 * 伪元素不随 :hover 常规重算，显形后可能冻结不消失。改为 mouseover/scroll/mouseout
 * 事件给活跃滚动容器切换 scrollbar-live 类（base.css 消费），行为 =
 * hover 或滚动中显形、停止滚动 700ms 且鼠标不在时隐藏、移出窗口立即隐藏。
 */
export declare function initScrollbarAutoHide(owner?: Document): () => void;
