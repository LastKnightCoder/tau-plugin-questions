export interface PresentationFrame {
    id: string;
    elements: string[];
}
export interface PresentationSequence {
    id: string;
    name: string;
    frames: PresentationFrame[];
    createTime: number;
    updateTime: number;
}
