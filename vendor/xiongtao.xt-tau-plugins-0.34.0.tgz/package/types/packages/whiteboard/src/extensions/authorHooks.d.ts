import type { BoardElement } from "../types/element";
export declare function usePageSketch(): import("../author").PageSketch;
/** 订阅所属画布的画风，元素和 owner 的覆盖仍由内核统一解析。 */
export declare function useSketch(element: BoardElement, owner?: BoardElement): import("../author").ResolvedSketch;
