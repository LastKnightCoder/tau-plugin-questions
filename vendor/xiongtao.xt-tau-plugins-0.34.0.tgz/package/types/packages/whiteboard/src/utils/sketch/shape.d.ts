import type { SketchFillStyle, SketchLevel } from "../../types/sketch";
import { type Polyline, type Vec } from "./geometry";
import type { SketchPath } from "./types";
export type SketchOutline = {
    kind: "rect";
    cornerRadius?: number;
} | {
    kind: "ellipse";
}
/** 已缩放到元素尺寸的 path d（几何配置经 transformPath 的结果） */
 | {
    kind: "path";
    paths: string[];
};
export interface SketchShapeInput {
    outline: SketchOutline;
    width: number;
    height: number;
    stroke?: string;
    strokeWidth: number;
    strokeOpacity?: number;
    fill?: string;
    fillOpacity?: number;
    fillStyle?: SketchFillStyle;
    /** 描边线型：只对圆角矩形生效；缺省实线 */
    strokeDash?: "dashed" | "dotted";
    /** 淡涂叠在纸上的不透明度系数，缺省 WASH_ALPHA；底色承载文字对比度时（导图节点）传 1 */
    washAlpha?: number;
    level: SketchLevel;
    seed: number;
}
export declare function outlinePolylines(outline: SketchOutline, width: number, height: number): Polyline[];
/** 闭合轮廓一笔绕一圈：随机起点，末尾一小段向外搭接，形成手绘的收口 */
export declare function loopStroke(loop: Vec[], amplitude: number, random: () => number, overlapRatio?: number): Vec[];
/** 排线间距随线宽变粗、随形状尺寸微调：大形状不稀、小形状不糊 */
export declare const hatchGap: (strokeWidth: number, width: number, height: number) => number;
/** 形状的手绘渲染：填充在下、轮廓墨迹在上。坐标系为元素局部坐标（0,0 ~ width,height） */
export declare function sketchShape(input: SketchShapeInput): SketchPath[];
