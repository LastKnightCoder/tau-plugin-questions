import type { SketchPath } from "../../utils/sketch/types";
interface SketchPathsProps {
    paths: SketchPath[];
    /** 虚线流动：遮罩 dashoffset 走完一个周期的秒数；不传则静止 */
    dashFlowDuration?: number;
}
/** 渲染 utils/sketch 的输出：墨迹与淡涂是填充多边形，线类填充裁剪在轮廓内，虚线经遮罩切段 */
declare const SketchPaths: import("react").MemoExoticComponent<({ paths, dashFlowDuration }: SketchPathsProps) => import("react/jsx-runtime").JSX.Element>;
export default SketchPaths;
