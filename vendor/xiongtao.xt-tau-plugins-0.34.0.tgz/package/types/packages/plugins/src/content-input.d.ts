/**
 * 正文输入：新建内容与修改正文时统一使用。宿主写入前校验结构；节点类型不做白名单，
 * 未注册的类型与编辑器对缺包节点的处理一致，原样保存。
 */
import type { Descendant } from "slate";
import type { PluginContentRef } from "./data";
/** 编辑器节点结构的版本：节点形状有不兼容变化时递增，随 nodes 格式的正文快照返回 */
export declare const EDITOR_NODE_SCHEMA_VERSION = 1;
export type PluginContentInput = 
/** Markdown，宿主转换为节点；Markdown 表达不了的格式会丢失 */
{
    markdown: string;
}
/** 编辑器节点，原样写入，与 content.read 的 nodes 格式相同 */
 | {
    nodes: Descendant[];
}
/** 整份复制一份已有正文：只需要目标的写入权限，插件拿不到正文 */
 | {
    copyOf: PluginContentRef;
};
export declare const CONTENT_INPUT_LIMITS: Readonly<{
    markdown: 2000000;
    /** 节点序列化为 JSON 后的字符数 */
    nodes: 8000000;
    /** 节点层级；每层节点占 copyJson 两层（对象与 children），与其 64 层上限对齐 */
    depth: 30;
}>;
/** 节点结构校验：顶层为元素；元素有 type 与非空 children；文本节点有 text、没有 children。 */
export declare function assertContentNodes(value: unknown): asserts value is Descendant[];
/** 读取并复制插件传入的正文输入；allowEmpty 为 false 时拒绝空 Markdown 与空节点数组。 */
export declare function readContentInput(value: unknown, options: {
    allowEmpty: boolean;
}): PluginContentInput;
