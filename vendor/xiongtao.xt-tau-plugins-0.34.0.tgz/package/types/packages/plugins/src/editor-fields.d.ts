import type { PluginEditorExtension } from "./editor";
/** 向插件开放的编辑器扩展字段；类型与运行时校验共用这一份，新增开放须同时评估宿主隔离。 */
declare const OPEN_EXTENSION_FIELDS: readonly ["id", "apiVersion", "elements", "commands", "hotkeys", "menu", "blockPanel", "behaviorsFor"];
export type OpenEditorExtensionField = (typeof OPEN_EXTENSION_FIELDS)[number];
/**
 * 运行时按白名单校验插件给的编辑器扩展：编辑器装配直接读取属性，类型约束拦不住纯 JS 插件，
 * 继承或不可枚举的属性同样会被读到，所以要求普通对象且自有键全部开放。
 */
export declare function assertPluginEditorExtension(extension: unknown): asserts extension is PluginEditorExtension;
export {};
