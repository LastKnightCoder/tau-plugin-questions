export { assertLocalId } from "./ids";
import { type PluginCategory } from "./categories";
import { type PluginPermission } from "./permissions";
import { type PluginBackendManifest } from "./backend-manifest";
export { validateBackendManifest, PLUGIN_SYSTEM_ACCESS, type PluginBackendManifest, type PluginSystemAccess, } from "./backend-manifest";
export { comparePluginVersions } from "./version";
export { PLUGIN_CATEGORIES, PLUGIN_KEYWORD_LIMIT, PLUGIN_KEYWORD_MAX_LENGTH, isPluginCategory, type PluginCategory, } from "./categories";
export { PLUGIN_PERMISSIONS, isPluginPermission, type PluginPermission } from "./permissions";
export { PLUGIN_AI_CAPABILITIES, isPluginAICapability } from "./ai";
export declare const PLUGIN_SHARED_MODULES: readonly ["@tau/plugins", "@tau/plugins/whiteboard", "@tau/plugins/sync", "@tau/ui", "react", "react-dom", "react-dom/client", "react/jsx-runtime", "react/jsx-dev-runtime"];
export interface PluginManifest {
    formatVersion: 1 | 2;
    id: string;
    name: string;
    version: string;
    minAppVersion?: string;
    apiVersion: 1;
    platform: "desktop";
    format: "cjs";
    main: string;
    backend?: PluginBackendManifest;
    styles?: string;
    /** 静态编辑器贡献在窗口启动时装配，启停需重启。 */
    editor?: true;
    whiteboard?: true;
    /** 插件中心分类，作者自填，不与实际注册对账。 */
    categories?: readonly PluginCategory[];
    /** 仅参与搜索匹配。 */
    keywords?: readonly string[];
    /** 可申请的业务数据权限上限；实际授权由用户在调用时决定。 */
    permissions?: readonly PluginPermission[];
    /** 包内 `skills/<id>/` 目录，随插件启停。 */
    skills?: readonly string[];
    integrity: Record<string, string>;
}
/** 宿主内部传输的已读取产物，不属于作者运行时 API。 */
export interface DevelopmentPluginPackage {
    manifest: PluginManifest;
    code: string;
    css?: string;
}
/** strict 供门户上传使用：分类、关键词或权限不合规时报错，客户端默认静默丢弃。 */
export declare function validatePluginManifest(value: unknown, options?: {
    strict?: boolean;
}): PluginManifest;
/** 静态内容贡献在启动时固定，启停与更新需要重启。 */
export declare const isContentPlugin: (manifest: Pick<PluginManifest, "editor" | "whiteboard">) => boolean;
