import type { Disposable } from "./contract";
import type { PluginPermission } from "./permissions";
/**
 * 业务数据变更事件。事件只说明「哪一项变了」，不携带数据：需要时用 context.data 重新读取。
 * 正文修改计入所属卡片、文章、项目文档或插件实体的 updated；Notebook 资料的增删改计入所属
 * Notebook 的 updated；待办与日程只给出集合级变化。entity.* 与 record.* 是本插件实体
 * （context.entities）与记录（context.records）的变化，只发给拥有它的插件。
 */
export declare const PLUGIN_EVENT_TYPES: readonly ["card.created", "card.updated", "card.deleted", "article.created", "article.updated", "article.deleted", "document.created", "document.updated", "document.deleted", "whiteboard.created", "whiteboard.updated", "whiteboard.deleted", "project.created", "project.updated", "project.deleted", "notebook.created", "notebook.updated", "notebook.deleted", "material.created", "material.updated", "material.deleted", "chat.created", "chat.updated", "chat.deleted", "entity.created", "entity.updated", "entity.deleted", "record.created", "record.updated", "record.deleted", "todos.changed", "calendar.changed", "workspace.reset"];
export type PluginEventType = (typeof PLUGIN_EVENT_TYPES)[number];
/** 变化来自哪里：插件经 context.data / context.content 写入时为 plugin，其余（用户、同步、AI 等）为 app */
export type PluginEventOrigin = {
    kind: "plugin";
    pluginId: string;
} | {
    kind: "app";
};
export interface PluginDomainEvent {
    type: PluginEventType;
    /** 实体事件给出与 context.data / context.entities 相同的 ID；集合级事件没有 */
    id?: string;
    /** entity.* 事件给出实体类型（registerKind 声明的 kind）；删除后读不到实体时据此区分 */
    kind?: string;
    /** record.* 事件给出记录所在的集合 */
    collection?: string;
    /** 宿主发出事件的时间（毫秒） */
    at: number;
    /** 用来忽略自己写入引起的事件；待办与日程的集合级事件恒为 app */
    origin: PluginEventOrigin;
}
/** 接收事件需要对应数据的读取权限；未获准时事件不送达，也不会弹窗询问 */
export declare const PLUGIN_EVENT_PERMISSIONS: Record<PluginEventType, PluginPermission | null>;
export declare const isPluginEventType: (value: unknown) => value is PluginEventType;
export interface PluginEvents {
    on(types: PluginEventType | readonly PluginEventType[], listener: (event: PluginDomainEvent) => void): Disposable;
}
