import type { PluginServices } from "./services";
declare let useServices: () => PluginServices | undefined;
/** 宿主绑定 React 上下文，作者只消费 usePluginServices。 */
export declare function configurePluginServiceAccess(read: typeof useServices): void;
/** 当前插件渲染作用域的服务；博客和无界面宿主不提供服务。 */
export declare function usePluginServices(): PluginServices | undefined;
export {};
