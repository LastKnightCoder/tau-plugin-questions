import type { Disposable } from "./contract";
import type { PluginPageHandle, PluginPageParams } from "./pages";
import type { PluginIcon, PluginIconProps } from "./icons";
/** 与 PluginIconProps 相同 */
export type PluginSidebarIconProps = PluginIconProps;
/** 与 PluginIcon 相同 */
export type PluginSidebarIcon = PluginIcon;
export declare const SIDEBAR_GROUPS: Readonly<{
    readonly daily: "daily";
    readonly knowledge: "knowledge";
    readonly learning: "learning";
    readonly ai: "ai";
    readonly sharing: "sharing";
    readonly plugins: "plugins";
}>;
export interface PluginSidebarGroupDefinition {
    id: string;
    title: string;
}
export interface PluginSidebarGroupHandle extends Disposable {
    readonly id: string;
}
export interface PluginSidebarItemDefinition {
    id: string;
    title: string;
    /** 传入 SVG 组件本身；缺省使用插件图标。 */
    icon?: PluginSidebarIcon;
    /** 缺省或分组不存在时归入默认插件分组。 */
    group?: string;
    page: PluginPageHandle;
    params?: PluginPageParams;
}
/** 子项色点，与宿主待办项目、分组同一套色板 */
export type PluginSidebarTone = "rose" | "orange" | "yellow" | "green" | "blue" | "purple" | "gray";
export interface PluginSidebarMenuEntry {
    title: string;
    /** 危险操作（如删除）显示为红色，并与前面的条目隔开 */
    danger?: boolean;
    run(): unknown;
}
export interface PluginSidebarChild {
    /** 在同一条目内唯一 */
    id: string;
    title: string;
    /** 点击后以这组参数打开条目的页面；当前页参数包含这组参数时，子项显示为选中 */
    params: PluginPageParams;
    tone?: PluginSidebarTone;
    /** 子项右侧的计数，0 不显示 */
    count?: number;
    /** 右键菜单 */
    menu?: readonly PluginSidebarMenuEntry[];
    /** 接收拖放：type 为 dragType 的参数，run 收到拖拽数据 */
    onDrop?: {
        type: string;
        run(data: string): unknown;
    };
}
/** 子项列表末尾的动作行（如「新建分组」） */
export interface PluginSidebarAction {
    title: string;
    /** 缺省为加号 */
    icon?: PluginSidebarIcon;
    run(): unknown;
}
/** 只改传入的字段；badge 为 null 或 0 时隐藏，action 为 null 时移除 */
export interface PluginSidebarItemUpdate {
    badge?: number | null;
    children?: readonly PluginSidebarChild[];
    action?: PluginSidebarAction | null;
}
export interface PluginSidebarItemHandle extends Disposable {
    update(patch: PluginSidebarItemUpdate): void;
}
export interface PluginSidebar {
    registerGroup(definition: PluginSidebarGroupDefinition): PluginSidebarGroupHandle;
    /** 条目所在页面在栈顶且侧栏展开时，子项与动作行展开在条目下方 */
    registerItem(definition: PluginSidebarItemDefinition): PluginSidebarItemHandle;
    /**
     * 拖拽类型：插件页面拖起数据时用 dataTransfer.setData(dragType(type), data)，
     * 子项 onDrop 声明同一个 type 才能接收；宿主和其他插件的拖拽不会落到插件子项上。
     */
    dragType(type: string): string;
}
/** 侧栏条目的展示状态，宿主据此渲染；回调已由宿主包装 */
export interface PluginSidebarItemState {
    badge: number;
    children: readonly PluginSidebarChild[];
    action: PluginSidebarAction | null;
}
export declare function sidebarDragType(pluginId: string, type: string): string;
/**
 * 校验并冻结一次 update 的结果；wrap 包装插件回调（宿主在里面核对插件仍处于启用状态），
 * 拖拽类型由 dragType 加上插件命名空间。
 */
export declare function snapshotSidebarUpdate(previous: PluginSidebarItemState, patch: PluginSidebarItemUpdate, options: {
    wrap: <A extends unknown[]>(run: (...args: A) => unknown) => (...args: A) => unknown;
    dragType: (type: string) => string;
}): PluginSidebarItemState;
