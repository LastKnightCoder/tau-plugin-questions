import type { ElementRuntime } from "../../editor/source-contracts";
export type { ElementAccess, BlockToolbarProps, BlockToolbarButtonProps, ElementRuntime, } from "../../editor/source-contracts";
export type { ElementFrame as EditorElementFrame } from "../../editor/contracts";
export declare function configureElement(value: ElementRuntime): void;
/** 读写当前节点：只读状态、外框选中、合并字段、删除、打开块菜单 */
export declare const useElement: ElementRuntime["useElement"];
/** 打开文档图片查看器，定位到该节点的第 index 个图片资源 */
export declare const useMediaViewer: ElementRuntime["useMediaViewer"];
export declare const BlockToolbar: ElementRuntime["BlockToolbar"];
export declare const BlockToolbarButton: ElementRuntime["BlockToolbarButton"];
export declare const BlockToolbarGap: ElementRuntime["BlockToolbarGap"];
