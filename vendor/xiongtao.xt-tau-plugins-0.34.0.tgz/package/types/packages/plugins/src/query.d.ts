/**
 * 插件自有数据（插件实体、记录）的查询：按声明的索引字段筛选与排序。
 * 子路径 `@tau/plugins/query` 供宿主主进程复核写入的值与查询参数。
 */
import type { JsonValue } from "./json";
/** 索引字段的类型 */
export type PluginIndexType = "string" | "number" | "boolean";
/** 字段名 → 类型；字段取自 meta（实体）或 data（记录）的顶层键 */
export type PluginIndexes = Record<string, PluginIndexType>;
export type PluginIndexValue = string | number | boolean;
/**
 * 一个字段的条件。直接给值表示等于，`null` 表示没有值（缺失或为 null）；
 * 同一对象里的多个运算符同时成立。类型与声明不符的值按没有值处理。
 */
export type PluginFieldCondition = PluginIndexValue | null | {
    eq?: PluginIndexValue | null;
    /** 不等于；没有值的也算不等于 */
    ne?: PluginIndexValue | null;
    /** 等于其中之一，可以包含 null */
    in?: (PluginIndexValue | null)[];
    gt?: string | number;
    gte?: string | number;
    lt?: string | number;
    lte?: string | number;
};
export type PluginWhere = Record<string, PluginFieldCondition>;
export interface PluginOrderBy {
    field: string;
    /** 默认 asc；升序时没有值的排在最前，降序时排在最后 */
    direction?: "asc" | "desc";
}
export type PluginQueryOperator = "eq" | "ne" | "in" | "gt" | "gte" | "lt" | "lte";
/** 校验后的条件：字段已声明，值与类型一致 */
export interface PluginQueryCondition {
    field: string;
    type: PluginIndexType;
    op: PluginQueryOperator;
    value: PluginIndexValue | null | (PluginIndexValue | null)[];
}
/** 校验后的排序；builtin 为宿主自带的列（如创建时间），否则为索引字段 */
export type PluginQueryOrder = {
    builtin: string;
    direction: "asc" | "desc";
} | {
    field: string;
    type: PluginIndexType;
    direction: "asc" | "desc";
};
export declare const QUERY_LIMITS: {
    readonly indexes: 16;
    readonly conditions: 16;
    readonly inValues: 100;
    readonly orderBy: 2;
    readonly textValue: 1000;
};
export declare const isIndexFieldName: (value: unknown) => value is string;
/** 校验索引声明；reserved 为宿主自带的排序列名，不能用作索引字段 */
export declare function readIndexes(value: unknown, reserved?: readonly string[]): PluginIndexes;
/** 校验筛选条件，字段必须已在 indexes 中声明 */
export declare function readWhere(value: unknown, indexes: PluginIndexes): PluginQueryCondition[];
/** 校验排序；builtins 为宿主自带的可排序列 */
export declare function readOrderBy(value: unknown, indexes: PluginIndexes, builtins: readonly string[]): PluginQueryOrder[];
/** 写入前核对：已声明为索引的字段，值必须是声明的类型或 null */
export declare function assertIndexedValues(values: Record<string, JsonValue | undefined>, indexes: PluginIndexes): void;
