import type { SourceEditorRuntime } from "../../editor/source-contracts";
export type { SourceBlockEditorProps, RuntimeStyleCompiler as PluginRuntimeStyleCompiler, SourceEditorRuntime, } from "../../editor/source-contracts";
export declare function configureSourceEditor(value: SourceEditorRuntime): void;
export declare const SourceBlockEditor: SourceEditorRuntime["SourceBlockEditor"];
export declare const useSourceBlock: SourceEditorRuntime["useSourceBlock"];
export declare const useReportPreviewError: SourceEditorRuntime["useReportPreviewError"];
export declare const insertSourceBlock: SourceEditorRuntime["insertSourceBlock"];
export declare const sourceBlockParagraphBehavior: SourceEditorRuntime["sourceBlockParagraphBehavior"];
