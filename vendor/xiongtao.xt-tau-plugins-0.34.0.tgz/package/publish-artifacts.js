import {
  PLUGIN_SHARED_MODULES,
  validatePluginManifest
} from "./client/chunk-FZTR4KOY.js";

// packages/db-schema/content-resources.ts
var CONTENT_RESOURCE_KINDS = [
  "image",
  "video",
  "audio",
  "file"
];
var UNSAFE_SEGMENTS = /* @__PURE__ */ new Set(["__proto__", "constructor", "prototype"]);
var SEGMENT = /^[A-Za-z_$][\w$-]*(\[\])?$/;
var FIELD = /^[A-Za-z_$][\w$-]*$/;
var MAX_SPECS = 16;
var MAX_PATH_LENGTH = 128;
var isField = (value) => typeof value === "string" && FIELD.test(value) && !UNSAFE_SEGMENTS.has(value);
function isValidPath(path) {
  if (typeof path !== "string" || !path || path.length > MAX_PATH_LENGTH) return false;
  const parts = path.split(".");
  return parts.every(
    (part, index) => SEGMENT.test(part) && !UNSAFE_SEGMENTS.has(part.replace(/\[\]$/, "")) && (index < parts.length - 1 || !part.endsWith("[]"))
  );
}
function isContentResourceSpec(value) {
  if (!value || typeof value !== "object" || Array.isArray(value)) return false;
  const spec = value;
  return isValidPath(spec.path) && CONTENT_RESOURCE_KINDS.includes(spec.kind) && ["preview", "alt", "caption"].every((key) => spec[key] === void 0 || isField(spec[key])) && Object.keys(spec).every((key) => ["path", "kind", "preview", "alt", "caption"].includes(key));
}
function assertContentResourceSpecs(value) {
  if (!Array.isArray(value) || value.length > MAX_SPECS || !value.every(isContentResourceSpec))
    throw new Error("\u8D44\u6E90\u58F0\u660E\u65E0\u6548");
}

// packages/plugins/src/editor-fields.ts
var OPEN_EXTENSION_FIELDS = [
  "id",
  "apiVersion",
  "elements",
  "commands",
  "hotkeys",
  "menu",
  "blockPanel",
  "behaviorsFor"
];
var PLUGIN_EXTENSION_FIELDS = /* @__PURE__ */ new Set([
  ...OPEN_EXTENSION_FIELDS,
  "styleSources",
  "htmlSerializers"
]);
function assertPluginEditorExtension(extension) {
  if (typeof extension !== "object" || extension === null) throw new Error("\u7F16\u8F91\u5668\u6269\u5C55\u5FC5\u987B\u662F\u5BF9\u8C61");
  const prototype = Object.getPrototypeOf(extension);
  if (prototype !== Object.prototype && prototype !== null)
    throw new Error("\u7F16\u8F91\u5668\u6269\u5C55\u5FC5\u987B\u662F\u666E\u901A\u5BF9\u8C61");
  if ("plugins" in extension) throw new Error("\u7F16\u8F91\u5668\u63D2\u4EF6\u4E0D\u652F\u6301\u539F\u59CB Slate \u5305\u88C5\u5668");
  const closed = Reflect.ownKeys(extension).filter((key) => !PLUGIN_EXTENSION_FIELDS.has(key));
  if (closed.length)
    throw new Error(`\u7F16\u8F91\u5668\u6269\u5C55\u542B\u672A\u5F00\u653E\u7684\u5B57\u6BB5\uFF1A${closed.map((key) => String(key)).join("\u3001")}`);
}

// packages/plugins/src/rendering.ts
var PLUGIN_RENDER_VERSION = 1;
function evaluatePluginPackage(artifact, modules) {
  const manifest = validatePluginManifest(artifact.manifest);
  const module = { exports: {} };
  new Function(
    "require",
    "module",
    "exports",
    '"use strict";\n' + artifact.code + `
//# sourceURL=tau-plugin://${manifest.id}/${manifest.version}/main.js`
  )(
    (id) => {
      if (!PLUGIN_SHARED_MODULES.some((name) => name === id) || !Object.hasOwn(modules, id))
        throw new Error(`\u63D2\u4EF6\u4F7F\u7528\u4E86\u672A\u63D0\u4F9B\u7684\u5BBF\u4E3B\u6A21\u5757\uFF1A${id}`);
      return modules[id];
    },
    module,
    module.exports
  );
  return validatePluginDefinition(manifest, module.exports.default);
}
function validatePluginDefinition(manifest, definition) {
  if (!definition || typeof definition.create !== "function" || definition.id !== manifest.id || definition.name !== manifest.name || definition.version !== manifest.version || definition.apiVersion !== manifest.apiVersion)
    throw new Error("\u63D2\u4EF6\u5165\u53E3\u5B9A\u4E49\u4E0E\u6E05\u5355\u4E0D\u4E00\u81F4");
  if (Boolean(definition.editorExtensions?.length) !== Boolean(manifest.editor))
    throw new Error("\u7F16\u8F91\u5668\u8D21\u732E\u5FC5\u987B\u4E0E manifest.editor \u58F0\u660E\u4E00\u81F4");
  if (Boolean(definition.whiteboardExtensions?.length) !== Boolean(manifest.whiteboard))
    throw new Error("\u767D\u677F\u8D21\u732E\u5FC5\u987B\u4E0E manifest.whiteboard \u58F0\u660E\u4E00\u81F4");
  getPluginWhiteboardTypes(definition);
  if (definition.editorCodecs?.length && !manifest.editor)
    throw new Error("Markdown codec \u5FC5\u987B\u968F\u7F16\u8F91\u5668\u8D21\u732E\u58F0\u660E");
  if (manifest.editor) {
    const types = getPluginNodeTypes(definition);
    if (definition.editorCodecs?.some((codec) => !types.includes(codec.type)))
      throw new Error("\u63D2\u4EF6 codec \u53EA\u80FD\u58F0\u660E\u672C\u63D2\u4EF6\u63D0\u4F9B\u7684\u8282\u70B9\u7C7B\u578B");
  }
  return definition;
}
function getPluginNodeTypes(definition) {
  const types = [];
  for (const extension of definition.editorExtensions ?? []) {
    assertPluginEditorExtension(extension);
    for (const element of extension.elements ?? []) {
      if (!element.type || types.includes(element.type))
        throw new Error(`\u63D2\u4EF6\u8282\u70B9\u7C7B\u578B\u4E3A\u7A7A\u6216\u91CD\u590D\uFF1A${element.type}`);
      if (element.resources !== void 0) {
        try {
          assertContentResourceSpecs(element.resources);
        } catch {
          throw new Error(`\u63D2\u4EF6\u8282\u70B9\u8D44\u6E90\u58F0\u660E\u65E0\u6548\uFF1A${element.type}`);
        }
      }
      types.push(element.type);
    }
  }
  if (definition.editorExtensions?.length && !types.length)
    throw new Error("\u7F16\u8F91\u5668\u63D2\u4EF6\u5FC5\u987B\u58F0\u660E\u8282\u70B9\u7C7B\u578B");
  const htmlTypes = /* @__PURE__ */ new Set();
  for (const extension of definition.editorExtensions ?? []) {
    for (const source of extension.styleSources ?? [])
      if (!types.includes(source.type) || !source.field || !["html", "tsx"].includes(source.language))
        throw new Error("\u63D2\u4EF6\u6837\u5F0F\u6E90\u7801\u5FC5\u987B\u58F0\u660E\u672C\u63D2\u4EF6\u7684\u8282\u70B9\u5B57\u6BB5\u548C\u8BED\u8A00");
    for (const serializer of extension.htmlSerializers ?? []) {
      if (!types.includes(serializer.type) || htmlTypes.has(serializer.type) || typeof serializer.toHtml !== "function")
        throw new Error("\u63D2\u4EF6 HTML \u5BFC\u51FA\u7C7B\u578B\u91CD\u590D\u6216\u4E0D\u5C5E\u4E8E\u672C\u63D2\u4EF6");
      htmlTypes.add(serializer.type);
    }
  }
  return types;
}
function getPluginWhiteboardTypes(definition) {
  if (definition.whiteboardExtensions !== void 0 && !Array.isArray(definition.whiteboardExtensions))
    throw new Error("\u767D\u677F\u6269\u5C55\u58F0\u660E\u5FC5\u987B\u4E3A\u6570\u7EC4");
  const types = /* @__PURE__ */ new Set();
  const extensions = /* @__PURE__ */ new Set();
  for (const extension of definition.whiteboardExtensions ?? []) {
    if (!extension || typeof extension.id !== "string" || extension.apiVersion !== 1 || typeof extension.create !== "function" || extension.id !== definition.id && !extension.id.startsWith(`${definition.id}.`) || extensions.has(extension.id))
      throw new Error("\u767D\u677F\u6269\u5C55\u8EAB\u4EFD\u91CD\u590D\u6216\u4E0D\u5C5E\u4E8E\u5F53\u524D\u63D2\u4EF6");
    extensions.add(extension.id);
    if (!Array.isArray(extension.elements) || !extension.elements.length)
      throw new Error("\u767D\u677F\u63D2\u4EF6\u5FC5\u987B\u58F0\u660E\u9759\u6001\u5143\u7D20");
    for (const element of extension.elements) {
      if (!element || typeof element.type !== "string" || !element.type.startsWith(`${definition.id}.`) || types.has(element.type) || typeof element.render !== "function")
        throw new Error("\u767D\u677F\u5143\u7D20\u91CD\u590D\u3001\u7F3A\u5C11\u6E32\u67D3\u6216\u4E0D\u5C5E\u4E8E\u5F53\u524D\u63D2\u4EF6");
      types.add(element.type);
    }
  }
  return [...types];
}
function assertRenderTypes(definition, expected) {
  const actual = getPluginNodeTypes(definition);
  if (actual.length !== expected.length || actual.some((type) => !expected.includes(type)))
    throw new Error("\u53D1\u5E03\u7684\u8282\u70B9\u5F52\u5C5E\u4E0E\u63D2\u4EF6\u5B9A\u4E49\u4E0D\u4E00\u81F4");
}

// packages/plugins/src/publish-artifacts.ts
var PLUGIN_RENDER_VERSION2 = PLUGIN_RENDER_VERSION;
function evaluatePluginPackage2(artifact, modules) {
  return evaluatePluginPackage(artifact, modules);
}
function assertRenderTypes2(definition, types) {
  assertRenderTypes(definition, types);
}
export {
  PLUGIN_RENDER_VERSION2 as PLUGIN_RENDER_VERSION,
  PLUGIN_SHARED_MODULES,
  assertRenderTypes2 as assertRenderTypes,
  evaluatePluginPackage2 as evaluatePluginPackage,
  validatePluginManifest
};
