// packages/plugins/src/ids.ts
function assertLocalId(value) {
  if (typeof value !== "string" || !/^[a-zA-Z0-9][a-zA-Z0-9._-]{0,127}$/.test(value)) {
    throw new Error("\u63D2\u4EF6\u6807\u8BC6\u5FC5\u987B\u4E3A 1 \u81F3 128 \u4F4D\u5B57\u6BCD\u3001\u6570\u5B57\u3001\u70B9\u3001\u6A2A\u7EBF\u6216\u4E0B\u5212\u7EBF");
  }
}

// packages/plugins/src/version.ts
function parseVersion(value) {
  const match = /^(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)(?:-([0-9A-Za-z-]+(?:\.[0-9A-Za-z-]+)*))?(?:\+[0-9A-Za-z-]+(?:\.[0-9A-Za-z-]+)*)?$/.exec(
    value
  );
  if (!match) throw new Error(`\u7248\u672C\u53F7\u65E0\u6548\uFF1A${value}`);
  const pre = match[4]?.split(".") ?? [];
  if (pre.some((part) => /^\d+$/.test(part) && part.length > 1 && part.startsWith("0")))
    throw new Error(`\u7248\u672C\u53F7\u65E0\u6548\uFF1A${value}`);
  return { core: match.slice(1, 4), pre };
}
function comparePluginVersions(left, right) {
  const a = parseVersion(left);
  const b = parseVersion(right);
  const numeric = (x, y) => BigInt(x) === BigInt(y) ? 0 : BigInt(x) > BigInt(y) ? 1 : -1;
  for (let index = 0; index < 3; index++) {
    const result = numeric(a.core[index], b.core[index]);
    if (result) return result;
  }
  if (!a.pre.length || !b.pre.length)
    return a.pre.length === b.pre.length ? 0 : a.pre.length ? -1 : 1;
  for (let index = 0; index < Math.max(a.pre.length, b.pre.length); index++) {
    const x = a.pre[index], y = b.pre[index];
    if (x === void 0 || y === void 0) return x === void 0 ? -1 : 1;
    if (x === y) continue;
    const nx = /^\d+$/.test(x), ny = /^\d+$/.test(y);
    return nx && ny ? numeric(x, y) : nx !== ny ? nx ? -1 : 1 : x > y ? 1 : -1;
  }
  return 0;
}

// packages/plugins/src/categories.ts
var PLUGIN_CATEGORIES = [
  { id: "sync", label: "\u540C\u6B65" },
  { id: "upload", label: "\u8D44\u6E90\u4E0A\u4F20" },
  { id: "editor", label: "\u7F16\u8F91\u5668" },
  { id: "whiteboard", label: "\u767D\u677F" },
  { id: "blog-template", label: "\u535A\u5BA2\u6A21\u677F" },
  { id: "blog-publish", label: "\u535A\u5BA2\u53D1\u5E03" },
  { id: "ai", label: "AI" },
  { id: "skill", label: "Skill" },
  { id: "voice", label: "\u8BED\u97F3" },
  { id: "video", label: "\u89C6\u9891" },
  { id: "page", label: "\u9875\u9762" }
];
var PLUGIN_KEYWORD_LIMIT = 5;
var PLUGIN_KEYWORD_MAX_LENGTH = 20;
var categoryIds = new Set(PLUGIN_CATEGORIES.map((item) => item.id));
var isPluginCategory = (value) => typeof value === "string" && categoryIds.has(value);
function readCatalogFields(item, strict) {
  const fail = (message) => {
    if (strict) throw new Error(message);
  };
  const list = (value, name) => {
    if (value === void 0) return [];
    if (Array.isArray(value)) return value;
    fail(`${name} \u5FC5\u987B\u662F\u6570\u7EC4`);
    return [];
  };
  const categories = [];
  for (const value of list(item.categories, "categories")) {
    if (!isPluginCategory(value)) fail(`\u672A\u77E5\u63D2\u4EF6\u5206\u7C7B\uFF1A${String(value)}`);
    else if (!categories.includes(value)) categories.push(value);
  }
  const keywords = [];
  for (const value of list(item.keywords, "keywords")) {
    const keyword = typeof value === "string" ? value.trim() : "";
    if (!keyword || keyword.length > PLUGIN_KEYWORD_MAX_LENGTH)
      fail(`\u5173\u952E\u8BCD\u5FC5\u987B\u4E3A 1 \u81F3 ${PLUGIN_KEYWORD_MAX_LENGTH} \u5B57`);
    else if (!keywords.includes(keyword)) keywords.push(keyword);
  }
  if (keywords.length > PLUGIN_KEYWORD_LIMIT) {
    fail(`\u5173\u952E\u8BCD\u6700\u591A ${PLUGIN_KEYWORD_LIMIT} \u4E2A`);
    keywords.length = PLUGIN_KEYWORD_LIMIT;
  }
  return {
    ...categories.length ? { categories: Object.freeze(categories) } : {},
    ...keywords.length ? { keywords: Object.freeze(keywords) } : {}
  };
}

// packages/plugins/src/ai.ts
var PLUGIN_AI_CAPABILITIES = {
  chat: { name: "\u5BF9\u8BDD\u529F\u80FD" },
  titleSummary: { name: "\u6807\u9898\u603B\u7ED3" },
  webClip: { name: "\u7F51\u9875\u526A\u85CF" },
  podcastGeneration: { name: "\u64AD\u5BA2\u751F\u6210" },
  flashcardGeneration: { name: "\u95EA\u5361\u5236\u4F5C" },
  aiJudgement: { name: "\u7B54\u6848\u8BC4\u5224" },
  transcriptionOptimization: { name: "\u8F6C\u5F55\u65AD\u53E5\u4F18\u5316" },
  videoSummary: { name: "\u89C6\u9891\u603B\u7ED3" },
  videoEbookRewrite: { name: "\u89C6\u9891\u7535\u5B50\u4E66\u91CD\u5199" },
  vibeLearningImageDescription: { name: "\u56FE\u7247\u7406\u89E3" },
  contentMetadata: { name: "\u7B14\u8BB0\u5143\u4FE1\u606F" },
  contentInsights: { name: "AI \u6D1E\u89C1" }
};
var isPluginAICapability = (value) => typeof value === "string" && Object.hasOwn(PLUGIN_AI_CAPABILITIES, value);

// packages/plugins/src/permissions.ts
var aiPermissions = Object.keys(PLUGIN_AI_CAPABILITIES).map(
  (capability) => `ai:${capability}`
);
var PLUGIN_PERMISSIONS = [
  "cards:read",
  "cards:write",
  "cards:delete",
  "articles:read",
  "articles:write",
  "articles:delete",
  "documents:read",
  "documents:write",
  "documents:delete",
  "whiteboards:read",
  "whiteboards:write",
  "whiteboards:delete",
  "projects:read",
  "projects:write",
  "projects:delete",
  "todos:read",
  "todos:write",
  "todos:delete",
  "calendar:read",
  "calendar:write",
  "calendar:delete",
  "notebooks:read",
  "materials:read",
  "chats:read",
  "flashcards:read",
  "flashcards:write",
  ...aiPermissions
];
var permissionIds = new Set(PLUGIN_PERMISSIONS);
var isPluginPermission = (value) => typeof value === "string" && permissionIds.has(value);
function readPermissionsField(item, strict) {
  const fail = (message) => {
    if (strict) throw new Error(message);
  };
  if (item.permissions === void 0) return {};
  if (!Array.isArray(item.permissions)) {
    fail("permissions \u5FC5\u987B\u662F\u6570\u7EC4");
    return {};
  }
  const permissions = [];
  for (const value of item.permissions) {
    if (!isPluginPermission(value)) fail(`\u672A\u77E5\u63D2\u4EF6\u6743\u9650\uFF1A${String(value)}`);
    else if (!permissions.includes(value)) permissions.push(value);
  }
  return permissions.length ? { permissions: Object.freeze(permissions) } : {};
}

// packages/plugins/src/backend-manifest.ts
var PLUGIN_SYSTEM_ACCESS = ["filesystem", "network", "process"];
function validateBackendManifest(value) {
  if (!value || typeof value !== "object" || Array.isArray(value))
    throw new Error("\u540E\u53F0\u58F0\u660E\u5FC5\u987B\u662F\u5BF9\u8C61");
  const item = value;
  const keys = [
    "entry",
    "runtime",
    "apiVersion",
    "scope",
    "activation",
    "lifetime",
    "reason",
    "systemAccess",
    "tools"
  ];
  if (Object.keys(item).some((key) => !keys.includes(key))) throw new Error("\u540E\u53F0\u58F0\u660E\u5305\u542B\u672A\u77E5\u5B57\u6BB5");
  if (typeof item.entry !== "string" || !/^[\w./-]+\.js$/.test(item.entry) || item.entry.split("/").some((part) => !part || part === "." || part === ".."))
    throw new Error("\u540E\u53F0\u5165\u53E3\u5FC5\u987B\u662F\u5305\u5185 JS \u6587\u4EF6");
  if (item.runtime !== "node" || item.apiVersion !== 1)
    throw new Error("\u540E\u53F0\u8FD0\u884C\u65F6\u6216\u534F\u8BAE\u7248\u672C\u4E0D\u517C\u5BB9");
  if (item.scope !== "application" && item.scope !== "workspace") throw new Error("\u540E\u53F0\u4F5C\u7528\u57DF\u65E0\u6548");
  if (item.activation !== "on-demand" && item.activation !== "app-ready" && item.activation !== "workspace-ready")
    throw new Error("\u540E\u53F0\u6FC0\u6D3B\u65F6\u673A\u65E0\u6548");
  if (item.activation !== "on-demand" && item.activation !== (item.scope === "application" ? "app-ready" : "workspace-ready"))
    throw new Error("\u540E\u53F0\u6FC0\u6D3B\u65F6\u673A\u4E0E\u4F5C\u7528\u57DF\u4E0D\u5339\u914D");
  if (item.lifetime !== "idle" && item.lifetime !== "persistent")
    throw new Error("\u540E\u53F0\u751F\u547D\u5468\u671F\u65E0\u6548");
  if (typeof item.reason !== "string" || !item.reason.trim() || item.reason.length > 500)
    throw new Error("\u540E\u53F0\u7528\u9014\u5FC5\u987B\u4E3A 1 \u81F3 500 \u5B57");
  if (!Array.isArray(item.systemAccess) || new Set(item.systemAccess).size !== item.systemAccess.length || item.systemAccess.some((value2) => !PLUGIN_SYSTEM_ACCESS.includes(value2)))
    throw new Error("\u540E\u53F0\u7CFB\u7EDF\u7528\u9014\u5206\u7C7B\u65E0\u6548");
  let tools;
  if (item.tools !== void 0) {
    if (!Array.isArray(item.tools) || item.tools.length > 32 || !item.systemAccess.includes("process"))
      throw new Error("\u5916\u90E8\u5DE5\u5177\u987B\u58F0\u660E process \u7528\u9014\uFF0C\u6700\u591A 32 \u9879");
    const ids = /* @__PURE__ */ new Set();
    tools = Object.freeze(
      item.tools.map((tool) => {
        if (!tool || typeof tool !== "object" || Array.isArray(tool))
          throw new Error("\u5916\u90E8\u5DE5\u5177\u58F0\u660E\u65E0\u6548");
        const value2 = tool;
        if (Object.keys(value2).some((key) => !["id", "command", "args"].includes(key)) || typeof value2.id !== "string" || !/^[a-z][\w.-]{0,63}$/.test(value2.id) || ids.has(value2.id) || typeof value2.command !== "string" || !value2.command.trim() || value2.command.length > 1024 || /[\0\r\n]/.test(value2.command))
          throw new Error("\u5916\u90E8\u5DE5\u5177\u8EAB\u4EFD\u6216\u547D\u4EE4\u65E0\u6548");
        ids.add(value2.id);
        if (value2.args !== void 0 && (!Array.isArray(value2.args) || value2.args.length > 64 || value2.args.some(
          (arg) => typeof arg !== "string" || arg.length > 4096 || arg.includes("\0")
        )))
          throw new Error("\u5916\u90E8\u5DE5\u5177\u53C2\u6570\u65E0\u6548");
        return Object.freeze({
          id: value2.id,
          command: value2.command,
          ...value2.args ? { args: Object.freeze([...value2.args]) } : {}
        });
      })
    );
  }
  return Object.freeze({
    ...tools ? { tools } : {},
    entry: item.entry,
    runtime: "node",
    apiVersion: 1,
    scope: item.scope,
    activation: item.activation,
    lifetime: item.lifetime,
    reason: item.reason.trim(),
    systemAccess: Object.freeze([...item.systemAccess])
  });
}

// packages/plugins/src/skills.ts
var SKILL_ROOT = "skills";
var SKILL_README = "SKILL.md";
var SKILL_LIMITS = { skills: 32 };
var skillDirectory = (id) => `${SKILL_ROOT}/${id}`;
function readSkillsField(value) {
  if (value === void 0) return void 0;
  if (!Array.isArray(value) || value.length > SKILL_LIMITS.skills)
    throw new Error(`skills \u5FC5\u987B\u662F\u6700\u591A ${SKILL_LIMITS.skills} \u9879\u7684\u6570\u7EC4`);
  const ids = /* @__PURE__ */ new Set();
  for (const id of value) {
    if (typeof id !== "string") throw new Error("Skill ID \u65E0\u6548");
    assertLocalId(id);
    if (ids.has(id)) throw new Error(`Skill ID \u91CD\u590D\uFF1A${id}`);
    ids.add(id);
  }
  return ids.size ? Object.freeze([...ids]) : void 0;
}
function readSkillFiles(skills, integrity) {
  const files = {};
  const declared = new Set(skills ?? []);
  for (const [name, hash] of Object.entries(integrity)) {
    if (!name.startsWith(SKILL_ROOT + "/")) continue;
    const [, id, ...rest] = name.split("/");
    if (!declared.has(id) || !rest.length || rest.some((part) => !part || part === "." || part === ".."))
      throw new Error(`Skill \u6587\u4EF6\u4E0D\u5C5E\u4E8E\u5DF2\u58F0\u660E\u7684 Skill\uFF1A${name}`);
    if (typeof hash !== "string" || !/^[a-f0-9]{64}$/.test(hash))
      throw new Error("Skill \u6587\u4EF6\u7F3A\u5C11\u6709\u6548\u7684\u5B8C\u6574\u6027\u6458\u8981");
    files[name] = hash;
  }
  for (const id of declared)
    if (!files[`${skillDirectory(id)}/${SKILL_README}`])
      throw new Error(`Skill ${id} \u7F3A\u5C11 ${SKILL_README}`);
  return files;
}

// packages/plugins/src/package.ts
var PLUGIN_SHARED_MODULES = [
  "@tau/plugins",
  "@tau/plugins/whiteboard",
  "@tau/plugins/sync",
  "@tau/ui",
  "react",
  "react-dom",
  "react-dom/client",
  "react/jsx-runtime",
  "react/jsx-dev-runtime"
];
function validatePluginManifest(value, options = {}) {
  if (!value || typeof value !== "object" || Array.isArray(value))
    throw new Error("\u63D2\u4EF6\u6E05\u5355\u5FC5\u987B\u662F\u5BF9\u8C61");
  const item = value;
  if (item.formatVersion !== 1 && item.formatVersion !== 2 || item.apiVersion !== 1 || item.platform !== "desktop" || item.format !== "cjs")
    throw new Error("\u63D2\u4EF6\u5305\u683C\u5F0F\u3001API \u7248\u672C\u6216\u5E73\u53F0\u4E0D\u517C\u5BB9");
  if (typeof item.id !== "string") throw new Error("\u63D2\u4EF6 ID \u65E0\u6548");
  assertLocalId(item.id);
  if (typeof item.name !== "string" || !item.name.trim() || typeof item.version !== "string" || !/^\d+\.\d+\.\d+(?:-[\w.-]+)?$/.test(item.version))
    throw new Error("\u63D2\u4EF6\u540D\u79F0\u6216\u7248\u672C\u65E0\u6548");
  const file = (input, extension) => {
    if (typeof input !== "string" || !/^[\w./-]+$/.test(input) || input.split("/").some((part) => !part || part === "." || part === "..") || !input.endsWith(extension))
      throw new Error("\u63D2\u4EF6\u5165\u53E3\u6216\u6837\u5F0F\u8DEF\u5F84\u65E0\u6548");
    return input;
  };
  const main = file(item.main, ".js");
  const backend = item.backend === void 0 ? void 0 : validateBackendManifest(item.backend);
  if (item.formatVersion === 2 !== Boolean(backend))
    throw new Error("\u540E\u53F0\u58F0\u660E\u5FC5\u987B\u4F7F\u7528\u5305\u683C\u5F0F 2\uFF0C\u666E\u901A\u63D2\u4EF6\u4F7F\u7528\u683C\u5F0F 1");
  if (backend?.entry === main) throw new Error("\u540E\u53F0\u5165\u53E3\u4E0D\u80FD\u4E0E\u6E32\u67D3\u5165\u53E3\u76F8\u540C");
  if (backend && typeof item.minAppVersion !== "string")
    throw new Error("\u540E\u53F0\u63D2\u4EF6\u5FC5\u987B\u58F0\u660E\u6700\u4F4E\u5BA2\u6237\u7AEF\u7248\u672C");
  if (item.minAppVersion !== void 0) {
    if (typeof item.minAppVersion !== "string") throw new Error("\u6700\u4F4E\u5BA2\u6237\u7AEF\u7248\u672C\u65E0\u6548");
    comparePluginVersions(item.minAppVersion, item.minAppVersion);
  }
  const styles = item.styles === void 0 ? void 0 : file(item.styles, ".css");
  if (item.editor !== void 0 && item.editor !== true) throw new Error("editor \u53EA\u80FD\u58F0\u660E\u4E3A true");
  if (item.whiteboard !== void 0 && item.whiteboard !== true)
    throw new Error("whiteboard \u53EA\u80FD\u58F0\u660E\u4E3A true");
  const catalog = readCatalogFields(item, options.strict === true);
  const permissions = readPermissionsField(item, options.strict === true);
  const integrity = {};
  for (const name of [main, ...styles ? [styles] : [], ...backend ? [backend.entry] : []]) {
    const hash = item.integrity && typeof item.integrity === "object" ? item.integrity[name] : void 0;
    if (typeof hash !== "string" || !/^[a-f0-9]{64}$/.test(hash))
      throw new Error("\u63D2\u4EF6\u4EA7\u7269\u7F3A\u5C11\u6709\u6548\u7684\u5B8C\u6574\u6027\u6458\u8981");
    integrity[name] = hash;
  }
  const skills = readSkillsField(item.skills);
  if (skills)
    Object.assign(
      integrity,
      readSkillFiles(skills, item.integrity ?? {})
    );
  return Object.freeze({
    formatVersion: item.formatVersion,
    id: item.id,
    name: item.name,
    version: item.version,
    ...typeof item.minAppVersion === "string" ? { minAppVersion: item.minAppVersion } : {},
    apiVersion: 1,
    platform: "desktop",
    format: "cjs",
    main,
    ...backend ? { backend } : {},
    ...item.editor === true ? { editor: true } : {},
    ...item.whiteboard === true ? { whiteboard: true } : {},
    ...catalog,
    ...permissions,
    ...skills ? { skills } : {},
    integrity: Object.freeze(integrity),
    ...styles === void 0 ? {} : { styles }
  });
}
var isContentPlugin = (manifest) => manifest.editor === true || manifest.whiteboard === true;

export {
  assertLocalId,
  comparePluginVersions,
  PLUGIN_CATEGORIES,
  PLUGIN_KEYWORD_LIMIT,
  PLUGIN_KEYWORD_MAX_LENGTH,
  isPluginCategory,
  PLUGIN_AI_CAPABILITIES,
  isPluginAICapability,
  PLUGIN_PERMISSIONS,
  isPluginPermission,
  PLUGIN_SYSTEM_ACCESS,
  validateBackendManifest,
  PLUGIN_SHARED_MODULES,
  validatePluginManifest,
  isContentPlugin
};
